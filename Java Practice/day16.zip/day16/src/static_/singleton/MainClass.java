package static_.singleton;

public class MainClass {

	public static void main(String[] args) {
		
//		Singleton s1 = new Singleton();
//		Singleton s2 = new Singleton();
//		
//		System.out.println(s1);
//		System.out.println(s2);
		
		
//		Singleton s = Singleton.instance;
//		Singleton.instance = new ~~~~();
		
		
		
		//instance객체를 호출
		Singleton i1 = Singleton.getInstance();
		Singleton i2 = Singleton.getInstance();
		Singleton i3 = Singleton.getInstance();
		
		System.out.println(i1);
		System.out.println(i2);
		System.out.println(i3);
		
		
		//i는 몇일까요?
		System.out.println(i1.i);
		i2.i = 100;
		System.out.println(i3.i);
		
		
		
		
		
		
		
		
		
		
		
	}
}
