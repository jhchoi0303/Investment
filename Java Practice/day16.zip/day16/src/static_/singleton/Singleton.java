package static_.singleton;

public class Singleton {

	//싱글톤 패턴 : 객체를 여러번 호출 하더라도 한개만 생성되도록 디자인 하는 방법
	
	//1. 자신의 클래스 내부에서 스스로 객체를 1개 생성하고 (static선언 을통해 1개만 생성함)
	private static Singleton instance = new Singleton();
	
	//2. 외부에서 이 클래스의 객체를 생성할 수 없도록
	//   생성자를 1개만 생성하고 private 선언을 붙임
	private Singleton(){
		
	}
	//3. 외부에서 이 클래스의 객체 생성을 요구할 때
	//   1번에서 만들어둔 단 하나의 객체를 getter를 통해 제공합니다.
	
	public static Singleton getInstance() {
		return instance;
	}
	
	
	
	
	//변수 선언 (싱글톤 패턴에서는 일반 변수가 static성향을 갖음)
	int i = 10;
	
	
	
	
	
	
	
	
	
}
