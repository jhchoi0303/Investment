package final_.variable;

public class MainClass {

	public static void main(String[] args) {
		
		Person park = new Person("123123-1111111", "박중국");
		
		//park.nation = "중국";
		//park.ssn = "123123";
		park.name = "박마이클";
		
		System.out.println("국적:" + park.nation);
		System.out.println("주민번호:" + park.ssn);
		System.out.println("이름:" + park.name);
		
		
		Person kim = new Person("123123-2222222", "김중국");
		
		System.out.println(kim.ssn);
		System.out.println(kim.name);
		
	}
}
