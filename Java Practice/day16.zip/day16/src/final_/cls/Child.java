package final_.cls;

//final클래스는 통째로 상속 할 수 없습니다
public class Child { //extends Parent {

	Parent p = new Parent();
	
}
