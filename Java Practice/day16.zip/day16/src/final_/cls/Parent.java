package final_.cls;

public final class Parent {

}
