package final_.method;

public class Parent {

	public void method1() {}
	public void method2() {}
	public final void method3() {
		System.out.println("부모의 고유한 메서드");
	}
}
