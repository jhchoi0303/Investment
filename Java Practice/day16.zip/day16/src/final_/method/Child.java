package final_.method;

public class Child extends Parent {

	public void method1() {
		System.out.println("자식 클래스에서 오버라이딩1");
	}
	public void method2() {
		System.out.println("자식 클래스에서 오버라이딩2");
	}
	//final메서드는 오버라이딩의 금지
//	public void method3() {
//		
//	}
	
	public Child() {
		method1();
		method2();
		method3();
	}
	
	
	
	
	
	
}
