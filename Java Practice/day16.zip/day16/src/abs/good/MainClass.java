package abs.good;

public class MainClass {

	public static void main(String[] args) {
		
		 Store s = new Store();
		 
		 s.name = "호식이 과일가게";
		 s.orderApple();
		 s.orderBanana();
		 s.orderGrape();
		 s.orderMelon();
		 s.orderPeach();
		 
		 
		 System.out.println("-------------------");
		 //추상 클래스는 스스로 객체 생성이 불가능.
		 //반드시 상속받은 클래스를 이용해서 구체화 시키는 형태로 사용함.
		 
		 HeadStore hh = new Store();
		 hh.name = "호식이 과일가게2";
		 hh.orderApple();
		 hh.orderBanana();
		 hh.orderGrape();
		 hh.orderMelon();
		 hh.orderPeach();
		 
		 
		 
		 
	}
}
