package abs.good;

public class Store extends HeadStore {
	//통째로 생략됨....
	Store(){
		super();
	}

	@Override
	public void orderApple() {
		System.out.println("서울 지점 사과 500원");
		
	}

	@Override
	public void orderBanana() {
		System.out.println("서울 지점 바나나 600원");
		
	}

	@Override
	public void orderGrape() {
		System.out.println("서울 지점 포도 800원");
		
	}

	@Override
	public void orderMelon() {
		System.out.println("서울 지점 멜론 1000원");
		
	}
}
