package abs.good;

public abstract class HeadStore {

	/*
	 * 1. 메서드에 abstract가 붙으면 추상 메서드가 되며, 이 메서드는 상속을 통해
	 *    반드시 오버라이딩이 되어야 합니다. (오버라이딩 강제화)
	 * 
	 * 2. 추상메서드는 메서드의 {}부분이 없고 세미콜론으로 메서드 선언을 마감합니다.
	 * 
	 * 3. 추상메서드가 하나라도 존재하면 클래스도 추상 클래스가 되어야 합니다
	 * 
	 * 4. 추상 클래스는 추상 메서드만 선언할 필요는 없습니다.
	 *    일반변수, 일반메서드, 생성자 모두 선언할 수 있습니다 
	 */
	public abstract void orderApple();
	public abstract void orderBanana();
	public abstract void orderGrape();
	public abstract void orderMelon();
	
	//생성자
	public HeadStore() {
		System.out.println("생성자 호출");
	}
	
	//일반 변수
	public String name;
	
	//일반 메서드
	public void orderPeach() {
		System.out.println("복숭아의 가격은 모두 2000원");
	}
	
	
	
	
	
	
	
	
}
