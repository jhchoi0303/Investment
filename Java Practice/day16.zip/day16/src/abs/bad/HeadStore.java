package abs.bad;

public class HeadStore {
	
	//ex) 부모클래스에는 반드시 자식클래스에서 오버라이딩을 해야할 메서드가 존재합니다.
	public void orderApple() {
		System.out.println("지점에서 가격을 제시하세요");
	}
	
	public void orderBanana() {
		System.out.println("지점에서 가격을 제시하세요");
	}
	
	public void orderGrape() {
		System.out.println("지점에서 가격을 제시하세요");
	}
	
	public void orderMelon() {
		System.out.println("지점에서 가격을 제시하세요");
	}
	
}
