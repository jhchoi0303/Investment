package abs.bad;

public class Store extends HeadStore {

	public void orderApple() {
		System.out.println("서울 지점 사과는 500원");
	}
	
	public void orderBanana() {
		System.out.println("서울 지점 바나나는 600원");
	}
	
	public void orderMelon() {
		System.out.println("서울 지점 멜론은 1000원");
	}
	
	//중대한 실수! 반드시 오버라이딩 해야되는 메서드를 하지 않음.
	
}
