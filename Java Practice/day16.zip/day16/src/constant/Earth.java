package constant;

public class Earth {

	public static final double RADIUS = 6400;
	public static final double SURFACE;
	
	//정적 초기화자에서는 상수의 초기화가 가능합니다. (1번만 실행되는 특징)
	static {
		SURFACE = RADIUS * RADIUS * 4 * Math.PI;
	}
				
	//생성자 
	private Earth() {
		//RADIUS = 6400;
	}
	
	
}
