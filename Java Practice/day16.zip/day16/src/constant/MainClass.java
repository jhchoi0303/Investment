package constant;

public class MainClass {

	public static void main(String[] args) {
		//지구의 반지름, 겉넓이를 출력
		System.out.println(Earth.RADIUS);
		System.out.println(Earth.SURFACE);
		
	}
}
