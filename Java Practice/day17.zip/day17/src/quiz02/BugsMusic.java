package quiz02;

public class BugsMusic implements ISongList {

	String[] list = new String[100];
	int count = 0;
	//ISongList를 상속받아 기능을 완성하세요
	//insertList(song) - list에 순서대로 저장
	//playList() - list를 랜덤으로 출력
	//length() - 저장된 음악 개수 리턴
	
	public void insertList(String song) {
		list[count] = song;
		count++;
	}

	public void playList() {

		for(int i = 0; i < count; i++) {
			
			int ran = (int)(Math.random() * length());
			System.out.println(list[ran]);
		}
	}

	public int length() {
		return count;
	}
	
}
