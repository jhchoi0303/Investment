package quiz02;

public interface ISongList {
	
	public void insertList(String song);
	public void playList();
	public int length(); 
}
