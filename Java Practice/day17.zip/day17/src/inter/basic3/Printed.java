package inter.basic3;

//MS사에서 제공한 print 소프트웨어 사용방법
public interface Printed {

	public void print(String document);
	public void colorPrint(String document, String color);
	public int copy(int n);
	
}
