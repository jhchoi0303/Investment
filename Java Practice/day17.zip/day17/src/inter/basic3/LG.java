package inter.basic3;

public class LG implements Printed{

	@Override
	public void print(String document) {
		
		System.out.println("Life is good! LG");
		System.out.println(document);
	}

	@Override
	public void colorPrint(String document, String color) {
		
		System.out.println("Life is good! LG");
		System.out.println(color + "색상 출력");
		System.out.println(document);
	}

	@Override
	public int copy(int n) {
		
		System.out.println("Life is good! LG");
		System.out.println(n + "장 복사");
		
		return n;
	}

}
