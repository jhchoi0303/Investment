package inter.basic3;

public class Samsung implements Printed{

	@Override
	public void print(String document) {
		
		System.out.println("From samsung");
		System.out.println(document);
	}

	@Override
	public void colorPrint(String document, String color) {
		
		System.out.println("From samsung");
		System.out.println(color + "색 출력을 시작합니다!");
		System.out.println(document);
	}

	@Override
	public int copy(int n) {
		
		for(int i = 1; i<=n ; i++) {
			System.out.println(i + "장 복사");
		}
		
		return n;
	}

}
