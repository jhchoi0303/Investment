package inter.basic3;

public class MainClass {

	
	
	public static void main(String[] args) {
		
		Printed pt;
		
		pt = new Samsung();
		pt.colorPrint("가나다라", "검정");
		pt.print("마바사~");
		pt.copy(10);
		
		System.out.println("-----------------");
		
		pt = new LG();
		pt.colorPrint("가나다라", "검정");
		pt.print("마바사~");
		pt.copy(10);
		
		
		
	}
}
