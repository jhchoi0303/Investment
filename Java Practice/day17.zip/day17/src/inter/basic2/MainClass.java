package inter.basic2;

public class MainClass {

	public static void main(String[] args) {
		
		//1. Dog, Cat, Tiger를 생성해서 Animal에 저장합니다
		Animal baduk = new Dog();
		Animal nabi = new Cat();
		Animal hodol = new Tiger();
		
		//2. Animal[] 생성 후 dog, cat, tiger를 넣고 향상된 포문으로 Animal의 기능을 출력!
		Animal[] animals = {baduk, nabi, hodol};
		
		for( Animal a : animals  ) {
			a.eat();
		}
		
		
		System.out.println("-------------------------------");
		//3. IPet[] 을 생성 후 dog, cat, new GoldFish 를 저장하고, 향상된 포문으로 출력
		
		IPet[] pets = new IPet[3];
		
		//Animal, IPet 서로 연관이 없기 때문에 바로 배열에 적용시킬 수는 없습니다
		//하지만 내부객체가 위 두 타입과 관련이 있기 때문에 상호 타입변환이 가능함 (type)
		
		pets[0] = (IPet)baduk;
		pets[1] = (IPet)nabi;
		pets[2] = new GoldFish();
		
		for(IPet p : pets ) {
			p.play();
		}
		
		
		System.out.println("------------------------");
		/*
		 * 1. PetShop클래스를 생성
		 * 2. PetShop클래스 안에는 carePet(??) 일반 메서드 선언 (매개 변수는 모든 팻타입 클래스를 받을수 있도록 선언)
		 * 3. carePet의 기능은 instanceof을 사용해서 전달되는 클래스에 따라 해당 클래스를 출력!
		 * 
		 * 4. 메인에서 실행
		 */
		
		PetShop shop = new PetShop(); 
		shop.carePet( pets[0] );
		shop.carePet( (IPet)nabi );
		shop.carePet( new GoldFish() );
		
		
	}
}
