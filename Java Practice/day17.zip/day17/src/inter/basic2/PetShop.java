package inter.basic2;

public class PetShop {

	public void carePet(IPet p) {
		
		if(p instanceof Dog) {
			System.out.println("강아지를 돌봅니다");
		} else if(p instanceof Cat) {
			System.out.println("고양이를 돌봅니다");
		} else if(p instanceof GoldFish) {
			System.out.println("금붕어를 돌봅니다");
		}
	}
}




