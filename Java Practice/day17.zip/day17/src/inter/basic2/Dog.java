package inter.basic2;

//클래스 상속과 인터페이스의 구현을 동시에 하려면 extends를 먼저 써주면 됩니다
public class Dog extends Animal implements IPet{

	@Override
	public void eat() {
		System.out.println("강아지는 사료를 먹어요");
		
	}

	@Override
	public void play() {
		System.out.println("강아지는 밖에서 놀아요");		
	}
}
