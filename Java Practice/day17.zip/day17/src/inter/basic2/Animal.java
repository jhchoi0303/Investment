package inter.basic2;

public abstract class Animal {

	public String name;
	public int age;
	
	public abstract void eat();
}
