package inter.basic;

public class MainClass {

	public static void main(String[] args) {
		
		//인터페이스는 객체를 생성할 수 없습니다.
		//Inter1 i1 = new Inter1();
	
		Basic b = new Basic();
		
		b.method1();
		b.method2();
		b.method3();
		System.out.println(b.INCH);
		System.out.println(b.ABC);
		System.out.println(Inter1.INCH);
		System.out.println(Inter2.ABC);
		
		
		
		//인터페이스는 하나의 데이터 타입으로 취급할 수 있습니다.
		//Basic클래스를 Inter1 또는 Inter2 타입이 될 수 있도록 다형성을 구현하는 원리가 됩니다.
		
		//Inter1 i1 = b;
		Inter1 i1 = new Basic();
		
		System.out.println(i1.INCH);
		i1.method1();
		
		
		Inter2 i2 = new Basic();
		
		System.out.println(i2.ABC);
		i2.method2();
		
		
		
		
		
		
		
		
		
	
	
	}
}
