package inter.basic;

public interface Inter1 {

	//인터페이스는 상수, 추상메서드를 멤버로 갖습니다.
	
	//인터페이스에 변수를 선언하면 자동으로 상수로 선언됩니다.
	double INCH = 2.1;
	//인터페이스에 메서드를 선언하면 자동으로 추상메서드 선언됩니다.
	public void method1();
	
	
	
	
	
	
	//1.8이후에 static메서드의 선언이 가능해짐
	public static void test() {
		
	}
	
}
