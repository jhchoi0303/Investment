package inter.basic;

/*
 * 1. 인터페이스를 사용하려면 인터페이스를 구현(상속) 해야 합니다
 * 
 * 2. 인터페이스를 구현하는 키워드는 implements입니다.
 * 
 * 3. 인터페이스는 여러 인터페이스를 동시에 다중 상속 시킬수 있습니다
 * 
 * 4. 이 때 클래스에서 인터페이스 내부에 선언된 추상메서드를
 *    반드시 재정의 해야합니다.
 * 
 */

public class Basic implements Inter1, Inter2 {

	@Override
	public void method1() {
		System.out.println("Inter1의 메서드 호출");		
	}

	public void method2() {
		System.out.println("Inter2의 메서드 호출");
	}
	
	public void method3() {
		System.out.println("Basic의 메서드 호출");
	}
	
	
}
