


package day01;

public class Comments {

	public static void main(String[] args) {
		/*
		 * main함수를 쉽게 작성하려면 main이라 적고
		 * ctrl + space로 자동완성기능으로 작성할 수 있습니다.
		 * 
		 * sysout이라고 적고 ctrl +space로 println()출력문을
		 * 자동작성 할 수 있습니다.
		 * 
		 * 코드 실행 단축키는 ctrl + f11 입니다
		 * 
		 * 자바의 출력형식 3가지
		 * print() - 개행을 포함 x
		 * println() - 자동 개행을 포함
		 * printf() - 형식지정 출력문
		 * 
		 * ctrl+ z : 되돌리기
		 * ctrl+ a : 전체선택
		 * ctrl+ i : 자동 탭정렬
		 * ctrl+ / : 빠른 한줄 주석
		 * 
		 */

		System.out.println("Hello~~");
		System.out.println("bye~");
		System.out.println("gg");
		System.out.printf("%d + %d = %d \n", 5, 5, 10);

		/*
		 * 서식문자 종류
		 * %d 정수 데이터
		 * %f 실수 데이터
		 * %s 문자열 데이터
		 * 
		 * \n 줄 개행
		 * \t 탭 정렬
		 * 
		 */







	}
}
