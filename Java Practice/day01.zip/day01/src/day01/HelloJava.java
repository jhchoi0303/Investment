



package day01;

public class HelloJava {
	
	public static void main(String[] args){
		// \n을 이용해서 줄바꿈을 사용할수 있습니다.
		System.out.print("안녕?\n");;;;;;
		System.out.print("반가워요");
			
	
	
	
	
	
	
	}
}
