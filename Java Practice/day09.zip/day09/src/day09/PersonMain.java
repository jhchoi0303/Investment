package day09;

public class PersonMain {

	public static void main(String[] args) {
		
		Person p1 = new Person();
		p1.name = "홍길동";
		p1.age = 19;
		
		Person p2 = new Person();
		p2.name = "김길동";
		p2.age = 30;
		
		p1.info();
		p2.info();
		
	}
}
