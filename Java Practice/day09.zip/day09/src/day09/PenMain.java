package day09;

public class PenMain {

	public static void main(String[] args) {
		//Pen의 기능과 속성을 사용하려면
		//설계용 클래스를 통해 Pen객체를 생성해야 합니다.
		Pen blackPen = new Pen();
		
		//객체의 기능과 속성을 사용하기 위해서는
		//참조 연산자 (.) 을 사용합니다.
		blackPen.ink = "검정";
		blackPen.price = 500;
		
		blackPen.write();
		
		
		Pen redPen = new Pen();
		
		redPen.ink = "빨강";
		redPen.price = 1000;
		
		redPen.write();
		
		blackPen.write();
		
		redPen.info();
		blackPen.info();
		
		
		System.out.println(blackPen);
		System.out.println(redPen);
		
		
	}
}
