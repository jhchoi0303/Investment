package day09;

public class PhoneMain {

	public static void main(String[] args) {
		
		Phone basic = new Phone();
		basic.info();
		
		Phone blue = new Phone("파랑");
		blue.info();
		
		Phone galaxyS10 = new Phone("골드", "갤럭시s10");
		galaxyS10.info();
		
		//1. model과 price를 지정하는 생성자
		//main에서 아이폰, 500000원 객체 생성
		Phone iphone = new Phone("아이폰", 500000);
		iphone.info();
		
		//2. model, price, color를 지정하는 생성자
		//main에서 샤오미, 1000000원, 화이트 지정해서 객체생성
		Phone shaomi = new Phone("화이트","샤오미", 1000000);
		shaomi.info();
		
	}
}
