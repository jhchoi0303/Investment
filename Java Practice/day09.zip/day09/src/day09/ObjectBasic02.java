package day09;

public class ObjectBasic02 {

	public static void main(String[] args) {
		
		Calculator cal1 = new Calculator();
		Calculator cal2 = new Calculator();
		
		System.out.println("1번 계산기로 계산");
		cal1.add(4);
		cal1.add(5);
		System.out.println(cal1.result);
		
		System.out.println("2번 계산기로 계산");
		cal2.add(10);
		cal2.add(40);
		System.out.println(cal2.result);
		
		
		
		
	}
}
