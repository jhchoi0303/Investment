package day09;

public class Calculator {
	
	int result = 0;
	int add(int n) {
		result += n;
		return result;
	}
	
}
