package day09;

public class VarMain {

	public static void main(String[] args) {
		
		Variable v = new Variable();
		
		v.print(3);
		
		v.a = 100;
		v.print(4);
	}
}
