package day09;

public class People {

	String name;
	int age;
	int tall;
	
	void info() {
		System.out.println(name);
		System.out.println(age+ "세");
		System.out.println("키:" + tall );
	}
}
