package day09;

public class Phone {

	//멤버변수
	String color;
	String model;
	int price;
	
	//생성자 선언
	//생성자 이름은 클래스의 이름과 대/소문자 까지 같아야 하며, 반환유형은 적지 않습니다.
	Phone() {
		System.out.println("생성자 호출!");
		color = "회색";
		model = "애니콜";
		price = 200000;
	}
	//생성자 오버로딩(중복)
	//1.생성자는 중복해서 여러 개 선언할 수 있습니다.
	//2.단! 매개변수의 종류나, 개수가 달라야 합니다.
	Phone(String pColor) {
		color = pColor;
		model = "팬택 큐리텔";
		price = 300000;
	}
	
	Phone(String pColor, String pModel) {
		color = pColor;
		model = pModel;
		price = 400000;
	}
	//모델과 가격을 지정하는 생성자
	Phone(String pModel, int pPrice) {
		color = "블랙";
		model = pModel;
		price = pPrice;
	}
	//모든 변수를 지정하는 생성자
	Phone(String pColor, String pModel, int pPrice) {
		color = pColor;
		model = pModel;
		price = pPrice;
	}
	
	//메서드 선언
	void info() {
		System.out.println("----핸드폰 정보----");
		System.out.println("색상:" + color);
		System.out.println("모델:" + model);
		System.out.println("가격:" +  price);
	}
	
	
	
}
