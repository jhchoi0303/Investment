package day09;

public class Person {

	String name;
	int age;
	
	void info() {
		System.out.println(name);
		System.out.println(age + "세");
	}
}
