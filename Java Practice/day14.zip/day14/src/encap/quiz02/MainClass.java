package encap.quiz02;

public class MainClass {

	public static void main(String[] args) {
		
		Computer com = new Computer();
		com.cumputerInfo();
			
		com.getMouse().info();
	}
}
