package poly.quiz;

public class MainClass {

	public static void main(String[] args) {
		
		Warrior w1 = new Warrior("강한친구");
		Wizard w2 = new Wizard("구르미");

		Warrior me = new Warrior("나의케릭터");
		
		me.bash(w1);
		me.bash(w2);
		
		
	}
}
