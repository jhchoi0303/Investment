package poly.quiz;

public class Warrior extends Player{

	Warrior(String name) {
		this.name = name;
		this.hp = 1000;
		this.mp = 500;
	}
	
	
	void bash(Player p) {
		
		System.out.println(p.name + "님 스킬 적중");
		p.hp -= 100;
		
	}
}
