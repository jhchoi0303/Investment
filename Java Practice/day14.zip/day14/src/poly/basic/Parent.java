package poly.basic;

public class Parent {

	public void method1() {
		System.out.println("부모의 1번 메서드 호출");
	}
	
	public void method2() {
		System.out.println("부모의 2번 메서드 호출");
	}
}
