package poly.basic;

public class MainClass {

	public static void main(String[] args) {
		
		Parent p1 = new Parent();
		p1.method1();
		p1.method2();
			
		System.out.println("----------------");
		Child c = new Child();
		c.method1();
		c.method2(); //오버라이딩 된 메서드 실행
		c.method3();
		
		System.out.println("-----다형성적용-----");
		
		Parent p2 = c;
		System.out.println(p2); //같은 클래스
		System.out.println(c);  //같은 클래스
		
		p2.method1();
		p2.method2(); //오버라이딩 된 메서드 실행
		//p2.method3();
		
		/*
		 * 다형성을 적용하면 본래의 멤버(멤버변수, 메서드)를 사용할 수 없는 문제가 발생합니다.
		 * 단, 오버라이딩된 메서드는 정상 호출 할 수 있습니다. 
		 */
		
		
		
		
		
		
		
		
	}
}
