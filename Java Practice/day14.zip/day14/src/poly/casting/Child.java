package poly.casting;

public class Child extends Parent {

	public String var2;
	
	public void method2() {
		System.out.println("자식의 재정의된 2번 메서드 호출");
	}
	
	public void method3() {
		System.out.println("자식의 3번 메서드 호출");
	}
}
