package poly.casting;

public class MainClass {

	public static void main(String[] args) {
		
		Parent p = new Child();
		
		p.var1 = "홍길동";
		//p.var2 = "홍길자";
		p.method1();
		p.method2();
		//p.method3();
		
		System.out.println("----------------------");
		
		Child c = (Child)p;
		
		System.out.println(c.var1);
		c.var2 = "홍길자";
		c.method1();
		c.method2();
		c.method3();
		
		System.out.println("----------------------");
		
		/*
		 * 본래 자신으로 생성됬던 객체만, 강제타입변환으로 형변환이 가능합니다.
		 * 
		 */
		
		//Child cc = (Child)new Parent();
		Child cc = (Child)new Object();
		
		
		
		
		
		
		
		
	}
}
