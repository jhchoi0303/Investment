package poly.param;

public class Bus extends Vehicle{

	public void run() {
		System.out.println("버스가 달립니다");
	}
}
