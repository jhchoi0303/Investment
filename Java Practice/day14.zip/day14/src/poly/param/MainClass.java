package poly.param;

public class MainClass {

	public static void main(String[] args) {
		
		//Driver클래스의 drive메서드 2개를 실행.
	
		Driver park = new Driver();
		
		Bus b = new Bus();
		park.drive(b);
		
		park.drive(new Taxi());
		
	}
}
