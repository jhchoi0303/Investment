package poly.param;

public class Driver {

	Vehicle v;
	
	
	//운전하는 기능
//	public void drive(Bus b) {
//		b.run();
//	}
//	
//	public void drive(Taxi t) {
//		t.run();
//	}
	
	public void drive(Vehicle v) {
		v.run(); //오버라이딩 되어야 함
		this.v = v;
	}
	
	
	
	
}
