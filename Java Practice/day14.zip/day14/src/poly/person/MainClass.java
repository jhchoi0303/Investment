package poly.person;

public class MainClass {

	public static void main(String[] args) {
		
//		Student park = new Student("박찬호", 20, "12");
//		Student lee = new Student("이순신", 30, "13");
//		Student son = new Student("손흥민", 40, "14");
//		Teacher kim = new Teacher("김제동", 50, "연예인");
//		Teacher hong = new Teacher("홍길동", 60, "위인");
//		Employee choi = new Employee("최강창민", 30, "가수");
//		
//		Student[] stu = {park, lee, son};
//		//향상된 for문 학생의 정보를 출력.
//		for( Student s  :  stu ) {
//			System.out.println(s.info());
//		}
//		
//		Teacher[] tea = {kim, hong};
//		//향상된 for문 선생님의 정보를 출력.
//		for(Teacher t : tea) {
//			System.out.println(t.info());
//		}
//		
//		Employee[] emp = {choi};
//		System.out.println(choi.info());
		
		//1. 다형성을 적용시키면 타입을 통일해서 묶어서 사용이 가능합니다
		Person park = new Student("박찬호", 20, "12");
		Person lee = new Student("이순신", 30, "13");
		Person son = new Student("손흥민", 40, "14");
		Person kim = new Teacher("김제동", 50, "연예인");
		Person hong = new Teacher("홍길동", 60, "위인");
		Person choi = new Employee("최강창민", 30, "가수");
		
		Person[] people = {park, lee, son, kim, hong, choi };
	
		for(Person p : people ) {
			System.out.println(p.info());
		}
	
	}
}
