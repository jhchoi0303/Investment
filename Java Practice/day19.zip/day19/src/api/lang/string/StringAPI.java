package api.lang.string;

import java.util.Arrays;

public class StringAPI {

	public static void main(String[] args) {
		
		//charAt()
		String str = "111111-1234567";
		
		char result = str.charAt(7);
		System.out.println(result);
		
		//length()
		System.out.println("문자열길이:" +  str.length() );
		
		//replace() - 변환
		String str2 = "자바는 객체지향 언어입니다. 자바는 어렵습니다";
		
		String result2 = str2.replace("자바", "java");
		System.out.println(result2);
		
		String result3 = str2.replace(" ", "");
		System.out.println(result3);
		
		//substring() - 자르기
		/*
		 * substring() 
		 * 매개값을 한개를 주면, 앞 문자열을 제거
		 * 매개값으로 두개를 주면, 해당 인덱스 이상~미만 을 추출합니다.
		 * 
		 */
		String str3 = "111111-1234567";
		String result4 = str3.substring(7);
		
		System.out.println(result4);
		
		String result5 = str3.substring(0, 6);
		System.out.println(result5);
		
		
		//trim() -앞뒤 공백 제거
		String str4 = "   홍길동   ";
		System.out.println("trim:" + str4.trim());
		
		//split() - 특정 문자열 기준으로 잘라서 배열로 반환
		String str5 = "010-1234-5678";
		
		String[] arr = str5.split("-");
		System.out.println(Arrays.toString(arr));
		
		//valueOf() - 기본타입 -> 문자열
		int a = 10;
		double b = 3.14;
		
		String result6 = String.valueOf(a);
		String result7 = String.valueOf(b);
		
		System.out.println(result6 + result7);
		
		
		
		
		System.out.println(Math.abs(-100));
		
		System.out.println(Math.ceil(3.4));
		
		System.out.println(Math.max(4, 3));
		
	}
}
