package api.lang.string;

import java.util.Scanner;

public class Quiz01 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("주민번호 13자리를 입력하세요: ");
		String ssn = scan.next();
		
		
		ssn = ssn.replace("-", "");

	
		if(ssn.length() != 13) {
			System.out.println("주민번호 13자리를 입력하세요.");

		} else {

			switch(ssn.charAt(6)) {

			case '1':
				System.out.println("남성");
				break;
			case '2':
				System.out.println("여성");
				break;
			}

		}
		scan.close();
	}
}
