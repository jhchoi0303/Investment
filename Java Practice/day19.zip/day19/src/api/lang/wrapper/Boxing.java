package api.lang.wrapper;

public class Boxing {

	public static void main(String[] args) {
		
		int a = 100;
		double b = 3.14;
		char c = 'h';
		
		//기본타입변수 참조연산자 . 을 사용하면 아무 기능도 없습니다.
		//a.
		
		//Boxing : 기본타입 데이터를 객체타입으로 변환하는 방법.
		Integer val1 = new Integer(a);
		Double val2 = new Double(b);
		Character val3 = new Character(c);
		
		Object[] arr = {val1, val2, val3 };
		
		//Unboxing : 포장된 객체타입을 다시 기본타입으로 변환하는 방법.
		a = val1.intValue();
		b = val2.doubleValue();
		
		//AutoBoxing: 기본타입 데이터를 자동으로 객체로 변환
		Integer x = 100;
		Double y = 3.14;
		String s = "hi";
		
		//AutoUnboxing: 객체를 자동으로 기본타입으로 변환
		
		int result1 = x;
		double result2 = y;
		
		//AutoBoxing이후에 wrapper클래스들은 기본타입의 형을 변환하는 기능으로 자주 사용됩니다
		//문자열 -> 정수, 문자열 ->실수
		
		int i = Integer.parseInt("1");
		double i2 = Double.parseDouble("3.14");
		
		System.out.println(i + i2);
		
		
		
		
		
		
		
		
	}
}
