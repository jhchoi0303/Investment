package api.lang.system;

public class SystemTime {

	public static void main(String[] args) {
		
		/*
		 * 1970.1.1부터 현재까지 지난 시간을 밀리초로 반환
		 * 
		 * 메서드 수행 시간을 측정할 때 사용합니다.
		 * 
		 */
		
		long start = System.currentTimeMillis();
		System.out.println(start);
		
		long sum = 0;
		for(long i = 1; i< 1000000000L; i++) {
			sum +=i;
		}
				
		
		long end = System.currentTimeMillis();
		System.out.println(end);
		
		
		System.out.println("계산에:" + (end -start)*0.001 + "초 소요" );
		
		
		
		
		
	}
}
