package day07;

public class BreakEx03 {

	public static void main(String[] args) {
		
		//중첩반복문에서 탈출 (한번에 전부 탈출 하고 싶다면?)
		boolean bool = false; //탈출용 변수
		
		for(int i = 0; i < 3; i++) {
			
			for(int j = 0; j < 2; j++) {
				
				if(i == j) {
					bool = true;
					break;
				}
					
				
				System.out.println(i + "-" + j);
				
			}
		
			if(bool == true)
				break;
		}
		
		
		System.out.println("---------------------------------------");
		/*
		 * 내부 반복문에서 break를 사용해서 외부 반복문까지 
		 * 탈출 시키려면 외부반복문에 이름을 붙여 사용합니다
		 * 
		 */
		
		//A유니코드는 65, Z유니코드는 90 이기때문에
		banana: for(char u = 'A'; u <= 'Z'; u++) {
			
			for(char l = 'a'; l <= 'z'; l++) {
				
				if(l == 'f') {
					break banana;
				}
				
				System.out.println(u + "-" + l);
			}
		}
		
		
		
		
		
		
		
		
		
		
	}
}
