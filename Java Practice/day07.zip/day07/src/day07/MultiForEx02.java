package day07;

import java.util.Scanner;

public class MultiForEx02 {

	public static void main(String[] args) {
		
		/*
		 * 		*
		 *     ***
		 *    *****
		 *   *******
		 *  *********
		 */
		int star = 5;
		for(int i = 0; i < star; i++) {//행을 나타내는 용도
			
			for(int j = 0; j < star-1-i; j++) {
				System.out.print(" ");
			}
			
			for(int j = 0; j < 2*i+1; j++) {
				System.out.print("*");
			}
			
			System.out.println(); //줄바꿈
		}
		
		
		
		System.out.println("---------------------------------");
		
		//정수를 입력받아서 해당 숫자 까지 모든 소수의 합을 구하는 로직.
		Scanner scan = new Scanner(System.in);
		System.out.print("정수 입력>");
		
		int n = scan.nextInt();
		
		int count = 0;
		int sum = 0;
		
		for(int i = 1; i <= n; i++) {
			
			count = 0; //다시 소수검사를 하기전에 count초기화
			
			for(int j = 1; j <= i; j++) {
				
				if(i % j == 0) {
					count++;
				}
				
			}
			
			if(count == 2) {
				sum += i;
			}
		}
		
		//소수들의 합출력
		System.out.println(n + "까지 소수의 합:" + sum);
		
		
		
		
	}
}
