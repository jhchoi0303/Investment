package day07;

public class ContinueEx01 {

	public static void main(String[] args) {
		
		for(int i = 1; i <= 10; i++) {
		
			if(i == 5) {
				System.out.println("컨틴유를 만나서 증감식으로 이동");
				continue;
			}
			
			
			System.out.println(i);
		}
		
		System.out.println("--------------------------------");
		
		//while문에서 continue를 만나면 조건을 검사하러 이동.
		//증감식에 위치에 따라서 무한루프가 발생할 수 있으니 주의해야 합니다.
		
		int i = 1;
		while(i <= 10) {
			
			if(i % 2 == 1) {
				i++;
				continue;
			}
			
			System.out.println(i);
			
			i++;
		}
		
		
		
		
		
		
		
		
		
		
	}
}
