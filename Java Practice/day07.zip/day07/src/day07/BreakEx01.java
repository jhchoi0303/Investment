package day07;

public class BreakEx01 {

	public static void main(String[] args) {
		
		/*
		 * 무한 루프 
		 * - 무한루프는 반복의 횟수를 정확히 모를 때 사용하며, 특정 조건에서 반복문을
		 *   종료시키는 형태로 사용합니다.
		 * - 자바에서는 무한루프를 while(true) 라고 작성하면 무한루프가 됩니다
		 */
		
		int i = 1;
		while(true) {
			
			if(i == 123) {
				break;
			}
			
			System.out.println(i);
			
			i++;
		}
		
		
		
		
		
		
	}
}







