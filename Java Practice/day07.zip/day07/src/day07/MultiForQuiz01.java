package day07;

import java.util.Scanner;

public class MultiForQuiz01 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("가로>");
		int width = scan.nextInt();
		System.out.print("세로>");
		int height = scan.nextInt();


		for(int i=1; i<=height; i++) {

			for(int j=1; j<=width; j++) {

				if(i == 1 || i == height) { //첫행과, 마지막행 별을 모두 출력
					System.out.print("*");
				} else { //첫행과 마지막행이 아닌 부분

					if(j == 1 || j == width) {//첫열과, 마지막막 별을 출력
						System.out.print("*");
					} else { //그렇지 않으면 공백출력
						System.out.print(" ");
					}
				}
			}

			System.out.println();//줄바꿈
		}
	}
}





