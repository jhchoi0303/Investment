package day07;

public class EnhancedFor {

	public static void main(String[] args) {
		
		String[] week = {"월", "화", "수", "목", "금", "토", "일"};
		
		//일반for문
//		for (int i = 0; i < week.length; i++) {
//			System.out.println(week[i] + "요일");
//		}
		
		//향상된 for문 (배열을 받아줄 변수 선언 : 배열 이름)
		
		for( String s  : week ) {
			System.out.println(s + "요일");
		}
		
		System.out.println("------------------------");
		
		//향상된 for문을 이용하여 총점, 평균 출력
		int[] score = {35, 65, 23, 64, 65};
		
		
		int sum = 0 ;
		for(int a : score) {
			sum += a;
		}
		
		System.out.println("총점:" + sum);
		
		System.out.println("평균:" + (double)sum / score.length);
		
		
		
		
	}
}
