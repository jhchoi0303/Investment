package day07;

import java.util.Scanner;

public class BreakEx02 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int noCount = 0; //오답 횟수
		
		while(true) {
			
			System.out.println("--------------");
			System.out.println("14 x 3 = ?");
			System.out.print(">");
			int answer = scan.nextInt();
	
			if(answer == 42) {
				System.out.println("오~ 정답입니다");
				break;
			}
			
			
			System.out.println("틀렸는데요?ㅎㅎ");
			System.out.println(++noCount + "번 틀렸네요");
		}
		
		
		
	}
}
