package modi.member.pac1;

public class A {

	//멤버변수
	public int var1;
	int var2;
	private int var3;
	
	//메서드 선언
	public void method1() {}
	void method2() {}
	private void method3() {}
	
	//생성자
	public A() {
		var1 = 1;
		var2 = 1;
		var3 = 1;
		
		method1();
		method2();
		method3();
		
	}
	
	
}
