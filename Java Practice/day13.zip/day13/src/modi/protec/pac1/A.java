package modi.protec.pac1;

public class A {

	/*
	 * protected는 다른 패키지일지라도 양 클래스 관계가 상속관계라면
	 * 제한적 접근을 허용하는 접근제한자 입니다.
	 */
	
	//멤버변수
	protected String var;
	
	//메서드
	protected void method() {}
	
	//생성자
	protected A() {}
	
}
