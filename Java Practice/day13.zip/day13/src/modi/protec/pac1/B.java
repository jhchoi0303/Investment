package modi.protec.pac1;

public class B {

	public B() {
		//protected 같은 패키지라면 접근이 가능
		A a = new A();
		a.var = "gg";
		a.method();
	}
	
	
	
}
