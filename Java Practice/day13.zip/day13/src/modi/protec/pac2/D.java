package modi.protec.pac2;

import modi.protec.pac1.A;

public class D extends A{

	public D() {
		
//		A a = new A();
//		a.var = "gg";
//		a.method();

		/*
		 * protected제한자는 패키지가 다른경우
		 * 두 클래스 사이에 상속관계가 있다면
		 * super를 통한 참조를 허용합니다.
		 */
		super();
		super.var = "gg";
		super.method();
	}
	
}
