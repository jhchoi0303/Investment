package modi.protec.pac2;

import modi.protec.pac1.A;

public class C {

	public C() {
		//protected는 default와 마찬가지로 다른 패키지라면 접근 불가
//		A a = new A();
//		a.var = "gg";
//		a.method1();
	}
	
}
