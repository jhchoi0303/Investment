package encap.quiz;

public class User {
	//멤버변수
	private String name;
	private int rrn;
	//생성자
	public User() {
		
	}
	public User(String name, int rrn) {
		this.name = name;
		this.rrn = rrn;
	}
	
	//getter/setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRrn() {
		return rrn;
	}
	public void setRrn(int rrn) {
		this.rrn = rrn;
	}
	
	
	
	
}
