﻿package encap.quiz;

public class MainClass {

	public static void main(String[] args) {
		/* 문제1
		 * 1. 저장 클래스 User를 생성
		 * 2. 멤버변수 name: String ,      rrn : int 를 선언후 캡슐화 시키세요 (private 지정)
		 * 3. User 클래스에는 기본생성자, 모든 멤버변수를  초기화 하는 생성자  2개를 생성하세요.
		 * 
		 * 4. main에서 User객체를 *기본생성자*로 생성 후  
		 *    (홍길동, 123123)을 저장 하고 값을 확인하세요.
		 */
			
		User u1 = new User();
		u1.setName("홍길동");
		u1.setRrn(123123);
		
		System.out.println("이름:" + u1.getName());
		System.out.println("번호:" + u1.getRrn());
		
		
		System.out.println("----------문제2----------");
		/* 문제2
		 * 1. 2개의 크기를 갖는 User배열을 선언하세요. (User배열은 User클래스를 저장할 수 있습니다.)
		 * 2. 두번째 User객체를 생성하세요. ("김길동", 456456)을 저장.
		 * 3. main에서는 User배열에 두 객체를 저장하세요.
		 * 4. for문을 사용해서 *모든변수"를 출력하세요
		 * 5. 향상된 포문을 사용해서  *모든변수*를 출력하세요.
		 */
		//1
		User[] arr = new User[2];
		//2
		User u2 = new User("김길동", 456456);
		//3
		arr[0] = u1;
		arr[1] = u2;
		//4
		for(int i = 0; i < arr.length; i++) {
			User u = arr[i];
			
			String name = u.getName();
			int rrn = u.getRrn();
			
			System.out.println(name);
			System.out.println(rrn);
		}
		
		//5
		System.out.println("----------------------");
		
		for( User u  : arr  ) {
			System.out.println(u.getName());
			System.out.println(u.getRrn());
		}
 		
		
		
		
		
		
		
		
		
		
	}
}
