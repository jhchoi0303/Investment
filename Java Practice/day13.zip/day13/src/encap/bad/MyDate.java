package encap.bad;

public class MyDate {

	int year;
	int month;
	int day;
	
	void dateInfo() {
		System.out.printf("내 생일은 %d년 %d월 %d일", year, month, day);
	}
}
