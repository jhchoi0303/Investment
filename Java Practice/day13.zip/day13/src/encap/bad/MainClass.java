package encap.bad;

public class MainClass {

	public static void main(String[] args) {
		
		MyDate my = new MyDate();
		my.year = 2019;
		my.month = 7;
		my.day = 32;
		
		my.dateInfo();
	}
}
