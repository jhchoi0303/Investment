package encap.good;

public class MainClass {

	public static void main(String[] args) {
		
		MyDate my = new MyDate();
		//my.day = 32;
		
		my.setDay(31); //setter메서드 사용
		
		int day = my.getDay();
		System.out.println(day + "일 입니다");
		
		my.setMonth(7);
		System.out.println(my.getMonth() + "월 입니다");
		
	}
}
