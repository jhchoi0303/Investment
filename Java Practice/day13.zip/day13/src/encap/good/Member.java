package encap.good;

public class Member {

	//회원의 정보저장을 하나의 클래스에 묶어서 사용.
	private String id;
	private String pw;
	private String name;
	private String email;
	private String ssn;
	

	//게터세터를 자동으로 생성하는법: alt + shift + s
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	
	
}
