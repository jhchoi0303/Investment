package encap.good;

public class MyDate {

	/*
	 * 은닉(캡슐화)를 사용하려면 데이터 저장을 제한할 멤버변수의  
	 * 앞에 private 제한자를 붙입니다.
	 */
	private int year;
	private int month;
	private int day;
	
	/*
	 * -은닉된 멤버변수에 접근하기 위해서
	 *  클래스 설계자 만들어 놓은 setter/getter메서드를
	 *  사용하여 데이터에 접근해야 합니다.
	 *  
	 * -setter메서드의 선언
	 * 1. setter메서드는 은닉변수에 값을 저장하기 위한 메서드입니다.
	 * 2. 메서드의 접근제한을 public으로 설정하고
	 *    이름을 일반적으로 set + 멤버변수명 으로 지정합니다.
	 */
	
	public void setDay(int day) {
		
		if(day < 1 || day > 31) {
			System.out.println("잘못된 일 입력입니다");
		} else {
			this.day = day;
		}
	}
	
	/*
	 * -getter메서드의 선언
	 * 1. getter메서드는 은닉변수의 값을 얻어낼 때 사용 메서드입니다.
	 * 2. setter와 마찬가지로 public제한을 주고, 
	 *    이름은 일반적으로 get + 멤버변수명 으로 지정합니다.
	 */
	
	public int getDay() {
		return day;
	}

	
	/*
	 * month에 대한 getter/setter 생성
	 * 1~12월 까지만 저장 할 수 있도록 기능을 작성하세요.
	 */
	
	public void setMonth(int month) {
		
		if(month < 1 || month > 12) {
			System.out.println("잘못된 월 수 입력입니다");
		} else {
			this.month = month;

		}
	}
		
	public int getMonth() {
		return month;
	}

	//year에 대한 게터/세터
	public void setYear(int year) {
		this.year = year;
	}
	
	public int getYear() {
		return year;
	}
	
	




	
	
	
	
	
	
}
