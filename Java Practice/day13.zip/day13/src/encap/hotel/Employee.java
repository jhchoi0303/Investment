package encap.hotel;

public class Employee {

	public void wash() {
		System.out.println("청소 합니다");
	}
}
