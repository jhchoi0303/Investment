package encap.hotel;

public class Hotel {

	private Employee emp;
	private Chef chef;
	
	public Hotel(){
		emp = new Employee();
		chef = new Chef();
	}
	
	//Employee의 getter/setter
	public void setEmp(Employee emp) {
		this.emp = emp;
	}
	
	public Employee getEmp() {
		return emp;
	}
	
	//Chef의 getter/setter
	public void setChef(Chef chef) {
		this.chef = chef;
	}
	
	public Chef getChef() {
		return chef;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
