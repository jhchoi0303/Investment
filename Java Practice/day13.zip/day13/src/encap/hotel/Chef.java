package encap.hotel;

public class Chef {

	public void cook() {
		System.out.println("요리 합니다");
	}
	
}
