package encap.hotel;

public class MainClass {

	public static void main(String[] args) {
		
		Hotel h = new Hotel();
		
//		Employee e = h.emp;
//		e.wash();
//		
//		Chef c = h.chef;
//		c.cook();
		
		Employee e = h.getEmp();
		Chef c = h.getChef();
		
		e.wash();
		c.cook();
		
		
	}
}
