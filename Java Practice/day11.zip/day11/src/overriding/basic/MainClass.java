package overriding.basic;

public class MainClass {

	public static void main(String[] args) {
		
		Parent p = new Parent();
		p.method1();
		p.method2();
		//자식클래스에 정의된 메서드는 부모에서 사용 불가
		
		System.out.println("--------");
		
		Child c = new Child();
		c.method1(); //상속받은 메서드
		c.method2(); //오버라이딩된 메서드
		c.method3(); //Child에 정의된 메서드
	}
}
