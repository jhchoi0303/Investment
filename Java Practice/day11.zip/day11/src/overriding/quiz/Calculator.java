package overriding.quiz;

public class Calculator {
	
	double circle(double r) {
		return 3.14 * r * r;
	}
}
