package overriding.quiz;

public class Computer extends Calculator {
	
	double circle(double r) {
		return Math.PI * r * r;		
	}
	
	
}
