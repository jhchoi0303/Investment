package overriding.quiz;

public class MainClass {

	public static void main(String[] args) {
		/*
		 * Calculator클래스, Calculator를 상속받는 Computer클래스 생성
		 * 
		 * Calculator클래스에는 circle()메서드를 생성
		 * 반환유형: double,
		 * 매개변수: double
		 * 
		 * 매개변수를 이용해서 원의 넓이를 구하는 circle()을 완성
		 * 
		 * Computer에서는 circle()메서드를 오버라이딩 하고,
		 * 3.14대신에 Math.PI를 사용해서 원의 넓이 리턴
		 * 
		 */
		System.out.println(Math.PI);
		
		Calculator cal = new Calculator();
		System.out.println("계산기로 원의넓이:" + cal.circle(9.0));
		
		Computer com = new Computer();
		System.out.println("컴퓨터로 원의넓이:" + com.circle(9.0));
		
		
		
		
		
		
		
		
		
	}
}
