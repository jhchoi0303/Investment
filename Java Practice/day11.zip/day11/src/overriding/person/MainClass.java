package overriding.person;

public class MainClass {

	public static void main(String[] args) {
		
		Person p = new Person();
		p.name = "홍길자";
		p.age = 20;
		System.out.println(p.info());
		
		Student s = new Student();
		s.name = "홍길순";
		s.age = 30;
		s.studentId = "123123";
		System.out.println(s.info());
		
		Employee e = new Employee();
		e.name = "김길동";
		e.age = 50;
		e.department = "구매부";
		System.out.println(e.info());
		
		Teacher t = new Teacher();
		t.name = "홍길동";
		t.age = 40;
		t.subject = "체육";
		System.out.println(t.info());
		
		
		
		
		
		
		
		
		
		
	}
}
