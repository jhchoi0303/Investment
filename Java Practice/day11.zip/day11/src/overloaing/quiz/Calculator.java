package overloaing.quiz;

public class Calculator {
	//오버라이딩 된 메서드
	double circle(double r) {
		return 3.14 * r * r;
	}
		
	//오버로딩 된 메서드
	//정사각형의 넓이를 구하는 메서드
	double rect(double len) {
		return len * len;
	}
	//직사각형의 넓이를 구하는 메서드
	double rect(double w, double h) {
		return w * h;
	}
	//직육면체의 넓이를 구하는 메서드
	double rect(double w, double w1, double h) {
		return w * h * w1;
	}
	
	
}
