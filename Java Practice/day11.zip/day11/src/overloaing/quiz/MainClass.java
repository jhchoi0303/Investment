package overloaing.quiz;

public class MainClass {

	public static void main(String[] args) {

		/*
		 * Calculator클래스
		 * 반환유형 double, 매개변수 double 인
		 * 정사각형의 넓이를 구하는 rect()
		 * 직사각형의 넓이를 구하는 rect()
		 * 직육면체의 넓이를 구하는 rect()
		 */
		
		Calculator cal = new Calculator();
		
		System.out.println("정사각형:" + cal.rect(3));
		System.out.println("직사각형:" + cal.rect(3, 4));
		System.out.println("직육면체:" + cal.rect(3, 4, 4.0));
		
	}
}
