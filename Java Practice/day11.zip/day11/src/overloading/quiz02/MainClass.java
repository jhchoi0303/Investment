package overloading.quiz02;

public class MainClass {

	public static void main(String[] args) {
		
		String[] sArr = {"홍길동", "홍길자", "홍길순"};
		int[] iArr = {1,2,3,4,5,6};
		char[] cArr = {'가', '나'};
		
		
		ArrayPrint ap = new ArrayPrint();
		
		ap.printArray(sArr);
		ap.printArray(iArr);
		ap.printArray(cArr);
		
		
		
	}
}
