package overloading.basic;

public class Basic {

	/*
	 * 오버로딩 규칙:
	 * 1. 메서드 이름이 같아야 함
	 * 2. 반환유형은 영향을 미치지 않음
	 * 
	 * # 3~5번은 3개의 조건중 반드시 하나 이상 만족해야 함
	 * 3. 매개 변수의 데이터 타입이 달라야 함
	 * 4. 매개 변수의 개수가 달라야 함
	 * 5. 매개 변수의 순서가 달라야 함
	 * 즉, 생김새 완전히 동일하지 않으면 됨.
	 */
	
	//input(int)
	void input(int a) {
		System.out.println("정수 1개가 입력");
	}
	//input(int) //반환유형은 영향을 미치지 않음
//	int input(int n) {
//		return 0;
//	}
	
	//input(String)
	void input(String str) {
		System.out.println("문자열 1개가 입력");
	}
	
	//input(int, int)
	void input(int a, int b) {
		System.out.println("정수 2개가 입력");
	}
	//input(String, double)
	void input(String str, double d) {
		System.out.println("문자열 1개 실수 1개가 입력");
	}
	//input(double, String)	
	void input(double d, String str) {
		System.out.println("실수 1개 문자열 1개가 입력");
	}

	
	
	
}
