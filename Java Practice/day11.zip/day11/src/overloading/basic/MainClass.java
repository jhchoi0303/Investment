package overloading.basic;

public class MainClass {

	public static void main(String[] args) {
		
		Basic b = new Basic();
		
		b.input(1);
		b.input(1, 2);
		b.input("1");
		b.input("안녕", 3.0);
		b.input(3.0, "바이바이");
		
		
	}
}
