package inherit.quiz;

public class MainClass {

	public static void main(String[] args) {
		
		Warrior w1 = new Warrior();
		w1.name = "구르미";
		w1.hp = 1000;
		w1.mp = 500;
		w1.info();
		w1.bash();
		
		Wizard w2 = new Wizard();
		w2.name = "강한친구";
		w2.hp = 500;
		w2.mp = 1000;
		w2.info();
		w2.iceArrow();
		
		
	}
}
