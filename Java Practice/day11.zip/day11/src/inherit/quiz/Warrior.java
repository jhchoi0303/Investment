package inherit.quiz;

public class Warrior extends Player{

	void bash() {
		System.out.println("배쉬 스킬 사용");
	}
}
