package inherit.quiz;

public class Wizard extends Player {

	void iceArrow() {
		System.out.println("얼음화살 사용");
	}
}
