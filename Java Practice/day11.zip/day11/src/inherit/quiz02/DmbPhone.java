﻿package inherit.quiz02;

public class DmbPhone extends Phone{

	int channel;
	
	//생성자와 메서드를 생성하세요
	DmbPhone(String pModel, String pColor, int ch) {
		model = pModel;
		color = pColor;
		channel = ch;
	}
	
	void turnOnDmb() {
		System.out.println("TV를 켭니다");
	}
	
	void changeChannel(int ch) {
		channel = ch;
		System.out.println(channel + "번 으로 변경!");
	}
	
	void turnOffDmb() {
		System.out.println("TV를 끕니다");
	}
	
}
