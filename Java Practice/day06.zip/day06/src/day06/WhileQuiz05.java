package day06;

import java.util.Arrays;
import java.util.Scanner;

public class WhileQuiz05 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("정수 입력:");
		int num = scan.nextInt();
		
		int[] arr = new int[num];
		
		int i = 0; //제어변수
		
		while(i < arr.length) {
			
			arr[i] = ++i;
			
			//arr[i] = i + 1;
			//i++;
		}
		
		
		System.out.println(Arrays.toString(arr));
		
		
		
		
		
	}
}
