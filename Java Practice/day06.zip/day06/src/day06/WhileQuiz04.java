package day06;

import java.util.Scanner;

public class WhileQuiz04 {

	public static void main(String[] args) {
			
		Scanner scan = new Scanner(System.in);
		
		int a = 1; //제어변수
		int sum = 0; //합계변수
		
		while(a != 0) {
						
			System.out.print("정수 입력>");
			a = scan.nextInt();
			
			sum += a;
		}
		
		System.out.println("입력받은 수의 합:" + sum);
		 
	}
}
