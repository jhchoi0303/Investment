package day06;

import java.util.Scanner;

public class DoWhileEx {

	public static void main(String[] args) {
		
		//정수를 입력받아서 1~입력받은 수 누적 합계
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("정수 입력>");
		int num = scan.nextInt();
		
		
		int i = 1;
		int sum = 0;

		
		do {
			sum += i;
			i++;
		} while(i <= num);
		
		
//		while(i <= num) {
//			
//			sum += i;
//			i++;
//		}
		
		System.out.println("누적 합:" + sum);
		
		
		
		
		
	}
}
