package day06;

import java.util.Scanner;

public class WhileEx02 {

	public static void main(String[] args) {
	
		//정수를 입력받아서 해당 정수가 소수 인지 판별.
		Scanner scan = new Scanner(System.in);
		
		System.out.print("정수 입력>");
		int n = scan.nextInt(); //n 소수를 판별할 정수
		
		
		int i = 2; //제어변수 : 소수판별을 위해 입력한 정수 n을 나눠볼 수
		
		while(n % i != 0) {
			
			i++;
		}
		
		
		if(n == i) {
			System.out.println(n + "소수 입니다");
		} else {
			System.out.println(n + "소수가 아닙니다");
		}
		
		
		
		
		
		
		
	}
}











