package day06;

public class MultiForEx01 {

	public static void main(String[] args) throws InterruptedException {
		
		
		for(int i = 2; i <= 9; i++) {//단에 대한 표현
			
			System.out.println("구구단 " + i + "단");
			
			for(int j = 1; j <= 9; j++) {//행에 대한 표현
				System.out.println(i + " x " + j + " = " + i*j);
				Thread.sleep(500);
			}
			
			
			System.out.println();
		}
		
		
	}
}
