package day06;

public class ForQuiz02 {

	public static void main(String[] args) {
		
		//7~100까지 정수 중 7의 배수 가로로 출력
		for(int i = 7; i <= 100; i+=7) {
			System.out.print(i + " ");
		}
				
		System.out.println("\n------------------------");
		//1~200까지 정수 중 9의 배수를 가로로 출력
		
		for(int i = 1; i <= 200; i++) {
			if(i % 9 == 0) {
				System.out.print(i + " ");
			}
		}
			
		System.out.println("\n------------------------");
		//1~100까지 정수 중에 8의 배수이면서, 16의 배수가 아닌 수의 합
		
		int sum = 0;
		for(int i = 1; i <= 100; i++) {
			
			if(i % 8 == 0 && i % 16 != 0) {
				sum += i;
			}
		}
		
		System.out.println("누적합:" + sum);
				
		
		System.out.println("\n------------------------");
		//1~600까지 정수 중 6의 배수의 개수
		int count = 0;
		
		for(int i = 1 ; i <= 600; i++) {
			
			if(i % 6 == 0) {
				count++;
			}
		}
		System.out.println("6의 배수의 개수:" + count);
		
		
		
		
	}
}
