package exception.trycatch;

public class MultiCatchEx {

	public static void main(String[] args) {
		
		//메인메서드에서 값을 전달받는 방법
		//run탭 -> run configurations탭 -> arguments탭을 클릭 값을 전달
		//${string_prompt} 을 주면, 실행시에 입력값을 받아들일 수 있음
		
		try {
			String data1 = args[0];
			String data2 = args[1];
			
			int var1 = Integer.parseInt(data1);
			int var2 = Integer.parseInt(data2);
			
			System.out.println("두 수의 합:" + (var1 + var2));
			
			
			String str = null;
			str.charAt(0);
			
			
		} catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("실행 매개값이 부족합니다");
			System.out.println("두개 넣어 주세요");
		} catch(NumberFormatException e) {
			System.out.println("데이터를 숫자로 변환할 수 없습니다");
			System.out.println("명령행 인자로 정수를 넣어주세요");
		} catch(Exception e) {
			System.out.println("기타 예외 입니다");
		} 
		
		
		
		
	}
}
