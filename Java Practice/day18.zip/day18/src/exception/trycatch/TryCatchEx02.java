package exception.trycatch;

public class TryCatchEx02 {

	public static void main(String[] args) {
		
		String[] arr = {"안녕", "hi", "니하오"};
		
//		try {
//			
//			int i = 0;
//			while( i < 4) {
//				
//				System.out.println(arr[i]);
//				
//				i++;
//			}
//			
//		} catch(Exception e) {
//			System.out.println("배열의 범위를 벗어났습니다.");
//		}
		
		int i = 0;
		while(i < 4) {
			
			try {
				System.out.println(arr[i]);
				
			} catch(Exception e) {
				System.out.println("배열의 범위를 벗어났습니다");
			} finally {
				System.out.println("이 문장은 예외 여부와 상관없이 항상 출력");	
			}
			
			i++;
		}
		
		
		
		
		
		
		
		
		
		
		System.out.println("프로그램 정상 종료");
		
		
		
	}
}
