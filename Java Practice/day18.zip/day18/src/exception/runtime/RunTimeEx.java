package exception.runtime;

public class RunTimeEx {

	public static void main(String[] args) {
		
		//NullPointer
//		String str = null;
//		str.equals("hi");
		
		//ArrayIndexBounds
//		int[] arr = {1,2,3};
//		System.out.println(arr[8]);
		
		//NumberFormat
//		String s = "hi";
//		int result = Integer.parseInt(s);
		
		//ClassCast
		String a = (String)new Object();
		
		
		
		
		
		
		
		
		
	}
}
