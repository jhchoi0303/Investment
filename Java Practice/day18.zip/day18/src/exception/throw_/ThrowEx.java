package exception.throw_;

public class ThrowEx {

	public static int calSum(int n) throws Exception {
		
		/*
		 * throw구문을 만나는 순간 예외를 발생시킴과 동시에
		 * 해당 예외를 처리할 catch블록을 검색합니다.
		 * 
		 * 보통 예외떠넘기기 방식과 함께 사용해서 메서드를 강제 종료합니다.
		 */
		
		if(n <= 0) {
			//System.out.println("매개값을 양수로 전달하세요");
			throw new Exception(); //예외 강제 발생
		}
		
		
		int sum = 0;
		for(int i = 1; i<= n; i++) {
			sum += i;
		}
		
		return sum;
	}
	
	
	public static void main(String[] args) {
		
		try {
			
			int result = calSum(10);
			System.out.println("1~10까지합:" + result);
			
			int result2 = calSum(-10);
			System.out.println("1~-10까지합:" + result2);
		
		} catch(Exception e) {
			System.out.println("매개값을 양수로 전달하세요");
		}

	}
	
	
	
	
	
	
	
}
