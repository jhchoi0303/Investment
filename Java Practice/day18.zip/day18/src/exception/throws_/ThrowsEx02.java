package exception.throws_;

public class ThrowsEx02 {

	//try구문과 throws 구문의 차이
	//try구문은 프로그램 흐름이 정상 흐름으로 흘러갑니다.
	//반면에 throws구문은 에러발생 시 메서드가 강제 종료됩니다.
	
	public void aaa() throws Exception {
		System.out.println("aaa호출");
		
//		try {
//			int i = 10/0;
//		} catch(Exception e) {
//			System.out.println("에러발생");
//		}
		
		int i = 10/0;
		
		System.out.println("aaa종료");
	}
	
	
	public void bbb() {
		System.out.println("bbb호출");
		try {
			aaa();
		} catch(Exception e) {
			System.out.println("에러발생");
		}
		
		
		System.out.println("bbb종료");
	}
	
	
	public ThrowsEx02() {
		System.out.println("생성자 호출");
		bbb();
		System.out.println("생성자 종료");
	}
}
