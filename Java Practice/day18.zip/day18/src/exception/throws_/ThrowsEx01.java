package exception.throws_;

public class ThrowsEx01 {
	
	/*
	 * 예외의 원인이 메서드 선언부가 아니라 호출하는 곳에 있을때
	 * 예외 처리를 호출자에게 떠넘기는 방식의 키워드를 throws라고 합니다.
	 * 
	 * throws는 메서드의 사용시 예외처리를 강요 하고싶을 때 사용합니다.
	 */
	
	public static String[] arr = {"안녕", "hi", "니하오"};
	
	public static void greet(int index) throws Exception {
		System.out.println(arr[index]);
	}
	
	
	
	
	
	public static void main(String[] args) {
		
		/*
		 * throws가 붙은 메서드를 호출할 때는
		 * 반드시 try블록 내부에서 호출하여 예외처리를 대신 진행해야 합니다.
		 */
		try {
			greet(5);
			
		} catch (Exception e) {
			System.out.println("배열의 참조범위를 벗어났습니다");
		}
		
	
		//throws처리가 되어있는 메서드 사용 예시
		try {
			Class.forName("홍길동클래스");//전달 되어 들어온 클래스를 읽어서 메모리상에 로딩 역할
			
		} catch (Exception e) {
			System.out.println("해당 클래스는 없습니다");
		}
		
		
		
		
		
		
	
	}
}







