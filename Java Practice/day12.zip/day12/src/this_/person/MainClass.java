package this_.person;

public class MainClass {

	public static void main(String[] args) {
		
		Person p1 = new Person("홍길자", 20);
		Person p2 = new Person("홍길순");
		Person p3 = new Person();
		
//		System.out.println(p1.info());
//		System.out.println(p2.info());
//		System.out.println(p3.info());
		
		Student s = new Student("홍길동", 30, "123123");
		System.out.println(s.info());
	}
}
