package this_.quiz;

public class Wizard extends Player {

	Wizard(String name) {
		this.name = name;
		this.hp = 500;
		this.mp = 1000;
	}
	
	
	void iceArrow() {
		System.out.println("얼음화살 사용");
	}
}
