package this_.quiz;

public class Warrior extends Player{

	Warrior(String name) {
		this.name = name;
		this.hp = 1000;
		this.mp = 500;
	}
	
	
	void bash() {
		System.out.println("배쉬 스킬 사용");
	}
}
