package this_.quiz;

public class MainClass {

	public static void main(String[] args) {
		
		Warrior w1 = new Warrior("강한친구");
		w1.info();
		
		
		Wizard w2 = new Wizard("구르미");
		w2.info();
		
		
	}
}
