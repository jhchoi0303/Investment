package this_.car;

public class MainClass {

	public static void main(String[] args) {
		
		Car myCar = new Car("다마스");
		myCar.run();
	}
}
