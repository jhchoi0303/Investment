package super_.person;

public class Student extends Person {

	String studentId; //학번
	
	//this. 를 이용해서 name age studentId를 전달받은 값으로 초기화하는 생성자
	Student(String name, int age, String studentId) {
		//super(); //생략
		//this.name = name;
		//this.age = age;
		super(name, age);
		this.studentId = studentId;
	}
	
	
	String info() {
		return "이름: " + name + ", 나이: " + age + ", 학번: " + studentId;
	}
	
}
