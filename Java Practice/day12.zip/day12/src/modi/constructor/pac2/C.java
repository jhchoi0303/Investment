package modi.constructor.pac2;

import modi.constructor.pac1.*;

public class C {

	A a1 = new A(true); //public (o)
	//A a2 = new A(3);	//default (x)
	//A a3 = new A("어렵다?"); //private (x)
}
