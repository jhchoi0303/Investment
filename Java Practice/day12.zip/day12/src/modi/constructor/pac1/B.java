package modi.constructor.pac1;

public class B {

	A a1 = new A(false); //public생성자 호출
	A a2 = new A(2); 	//default생성자 호출
	//A a3 = new A("바이"); //private생성자 호출
	
}
