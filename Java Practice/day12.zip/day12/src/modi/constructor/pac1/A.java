package modi.constructor.pac1;

public class A {

	//멤버변수
	A a1 = new A(true);
	A a2 = new A(1);
	A a3 = new A("안녕");
	
	//생성자 선언.
	public A(boolean b) {}
	A(int i) {}
	private A(String s) {}
	
}
