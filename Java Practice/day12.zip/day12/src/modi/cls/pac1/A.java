package modi.cls.pac1;

/*
 * default접근 제한은 접근제한자를 붙이지 않는 형태이며,
 * 같은 패키지 내부에서만 접근을 허용합니다.
 * 
 * class의 접근 제한자는 public, default 밖에 없습니다
 */


class A {

}
