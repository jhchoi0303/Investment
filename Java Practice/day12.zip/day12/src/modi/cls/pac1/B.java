package modi.cls.pac1;

public class B {

	/*
	 * 클래스 A의 접근제한자가 default이기 때문에
	 * 같은 패키지 내부에서 접근이 가능
	 * 
	 */
		
	//멤버변수
	int i = 1;
	A a = new A();
	
}
