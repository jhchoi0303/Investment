package modi.cls.pac2;

import modi.cls.pac1.*;

public class C {
	
	//default제한이 붙은 클래스는 다른 패키지에서 접근 불가
	//A a = new A();
	//public제한이 붙은 클래스 어디에서나 접근 가능
	B b = new B();
}
