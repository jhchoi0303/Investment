package day02;

public class TextEx {

	public static void main(String[] args) {
		
		//단일문자를 저장하는 char
		char c1 = 'A';
		char c2 = 65;
		System.out.println(c1);
		System.out.println(c2);
		
		//전세계 문자를 표현하기 위해서 유니코드 2의 16 = 65536개 문자
		//한글 '가' 에 유니코드 AC00
		//직접 유니코드를 저장할 떄 \\u 를 적어줘야 함.
		char c3 = '가';
		char c4 = 44032;
		char c5 = '\uAC00'; //유니코드 문자값
		
		System.out.println(c3 + " " + c4 + " " + c5);
		
		//문자열을 저장하는 String
		String s1 = "my dream ";
		String s2 = "is a president";
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s1 + s2);
		
		//문자열과 다른타입의 +연산
		//문자열에 +연산했을 때는 최종적으로 문자열로 결과가 출력
		System.out.println("-----------------------");
		System.out.println(100 + 200);
		System.out.println("100" + 200);
		System.out.println(100 + 200 + "300");
		System.out.println("100" + 200 + 300);
		
		//기본데이터 타입의 연산시 바이트가 큰 쪽에 맞추어 연산
		System.out.println('A' + 10);
		
		
		
	}
}
