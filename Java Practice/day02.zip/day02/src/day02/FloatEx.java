package day02;

public class FloatEx {

	public static void main(String[] args) {
		
		float f1 = 3.14F;
		double d1 = 3.14;
		
		float f2 = 1.234567891234F;
		double d2 = 1.234567891234;
		
		System.out.println(f2);
		System.out.println(d2);
		
		float f3 = 3.14e5F;
		System.out.println(f3);
		
		System.out.println("------------------------");
		//논리형
		boolean b1 = true;
		boolean b2 = false;
//		boolean b3 = 0;
//		boolean b4 = "1";
		
		
	}
}
