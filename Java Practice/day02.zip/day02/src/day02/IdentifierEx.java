package day02;

public class IdentifierEx {

	public static void main(String[] args) {
	
		//자바의 식별자이름 대/소문자를 구분함
		int age = 27;
		int Age = 28;
		int aGe = 29;
		
		System.out.println(27 + 27);
		System.out.println(age);
		System.out.println(Age);
		System.out.println(aGe);
		
		//식별자 이름을 숫자로 시작할수 없음
		//이름을 공백으로 사용 x
//		int 4num = 4; //ctrl + / 빠른 주석
		int num4 = 4;
//		int num 4 = 4;
		
		//식별자 이름으로 키워드를 사용할 수 없음
//		int class = 4;
//		int if = 3;
//		int void = 5;
		
		
		
	}
	
	
}
