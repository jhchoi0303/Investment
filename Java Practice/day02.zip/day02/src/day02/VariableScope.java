package day02;

public class VariableScope {

	public static void main(String[] args) {
		
		//변수의 사용범위
		//같은 타입의 변수를 선언할 때는 ,로 나열 할 수 있음.
		int num1 = 10, num2 = 20;
		int num4 = 0;
		
		if(num1 > 5) {
			
			int num3 = num1 + num2;
			//int num4 = 200;
			//num4의 변경한 값을 밖에서 사용하고 싶다면 선언을 중괄호 밖에.
			num4 = 200;
		}
		
		int num3 = 100;
		System.out.println(num3);
		
		System.out.println(num4);
		
	}
	
	
	
}
