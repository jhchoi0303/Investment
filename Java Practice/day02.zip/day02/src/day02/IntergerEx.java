package day02;

public class IntergerEx {

	public static void main(String[] args) {
		
		byte a = 127;
		short b = 32767;
		int c = 2147483647;
		long d = 2147483648L;
		
		//2진수 저장할때는 0b
		int bin = 0b1010;
		System.out.println("2진수 1010:" + bin + "입니다");
		
		//8진수 저장할때는 0
		int octa = 064;
		System.out.println("8진수 64:" + octa);
		
		//16진수 저장할때는 0x
		int hexa = 0x3a4c;
		System.out.println("16진수 3a4c:" + hexa);
		
		
	}
}
