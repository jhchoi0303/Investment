package day02;

public class VariableEx {

	public static void main(String[] args) {
		
		/*
		 * 변수의 선언 방법.
		 * 데이터타입 이름;
		 * 
		 * int는 정수를 저장하는 대표적인 유형
		 * String은 문자열을 저장하는 대표적인 유형
		 */
		
		int num1;
		//변수의 초기화
		num1 = 20;
		
		System.out.println(num1);
		
		//변수는 선언과 초기화를 동시에 할 수 있음
		int num2 = 30;
		
		//변수는 동일한 이름으로 여러개 선언할 수 없음
//		int num2;
		
		//변수는 다른 변수의 값을 저장 할 수 있습니다.
		int result = num2;
		
		result = 50;
		result = 600;
		result = num1 + num2;
		
		num1 = 10;
		num2 = 20;
		System.out.println(result);
		System.out.println(num1);
		System.out.println(num2);
		
		
		
		
		
	}
}
