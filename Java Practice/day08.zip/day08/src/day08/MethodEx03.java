package day08;

public class MethodEx03 {

	public static void main(String[] args) {
		/*
		 * 반환 유형(return type)
		 * 1. 반환값은 메서드를 호출한 곳으로 메서드의 실행결과를 전달하는 값입니다.
		 * 2. return뒤에 전달할 값을 지정합니다.
		 * 3. 반환 유형이란 이 전달할 값에 대한 데이터 타입 입니다.
		 * 
		 * 4. 반환 값이 있는 메서드는 호출문장이 하나의 값이 되기 때문에 다른 메서드의 매개값으로 사용하거나,
		 *    다른 변수에 저장해서 사용 할 수 있습니다.
		 *    
		 * 5. 모든 메서드가 반환값이 필요한건 아닙니다.
		 *    메서드 내부 실행만 하고 마치면 된다면 return을 사용하지 않아도 되고
		 *    이 때는 void라고 적어줘야 합니다.
		 *    
		 * 6. 모든 메서드는 return을 만나면 강제 종료 됩니다.
		 *    따라서 return문 아래에 코드를 작성할 수 없습니다.    
		 */
		int result = add(3, 5);
		
		int result2 = add( add(1,2), add(2,3) );
		System.out.println(result2);
		
		//void형 메서드는 단순 호출만 가능함
		//int result3 = multi(10, 20);
		//System.out.println( multi(10,20) );
		multi(10, 20);
		sub();
		
		sayHello("바보");
	} //end main
	
	//int형 매개 변수로 전달받은 2개의 값의 합을 반환하는 add메서드
	static int add(int a, int b) {
		return a+b;

	}
	
	//반환유형이 없는 메서드
	static void multi(int n1, int n2) {
		System.out.println(n1 + " x " + n2 + " = " + n1*n2);
	}
	
	//반환유형도 없고, 매개변수도 없는 메서드
	static void sub() {
		System.out.println("2 + 1 = 3");
	}
	
	static void sayHello(String nick) {
		
		if(nick.equals("바보") ) {
			System.out.println("바보 입니다");
			return; //종료
		}
		
		System.out.println(nick + "가 아니라 바보를 입력하세요");
	}
	
	
	
	
	
	
	
}
