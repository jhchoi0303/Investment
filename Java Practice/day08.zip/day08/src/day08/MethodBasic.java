package day08;

import java.util.Scanner;

public class MethodBasic {

	public static void main(String[] args) {
//		//print() void, void
//		System.out.println("정수 두개를 입력하세요>");
//		
//		//input() int, void
//		Scanner scan= new Scanner(System.in);
//		System.out.print("정수 입력>");
//		int num1 = scan.nextInt();
//		
//		System.out.print("정수 입력>");
//		int num2 = scan.nextInt();
//		
//		//add() int int,int
//		int result = num1 + num2;
//		
//		//showResult() void, int 
//		System.out.println("덧셈 결과:" + result);
		
		print();
		
		int num1 = input();
		int num2 = input();
		
		int result = add(num1, num2);
	
		showResult(result);
	}
	
	static void print() {
		System.out.println("정수 두개를 입력하세요>");
	}
	
	static int input() {
		Scanner scan= new Scanner(System.in);
		System.out.print("정수 입력>");
		int num1 = scan.nextInt();
		
		return num1;
	}
	
	static int add(int num1, int num2) {
		int result = num1 + num2;
		
		return result;
	}
		
	static void showResult(int result) {
		System.out.println("덧셈 결과:" + result);
	}
	
	
	
	
	
	
	
	
}
