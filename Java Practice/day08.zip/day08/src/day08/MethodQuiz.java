package day08;

import java.util.Arrays;

public class MethodQuiz {

	public static void main(String[] args) {
		
		method1();
		System.out.println(method2("안녕ㅋㅋ"));
		System.out.println(method3(10, 5, 2.2));
		System.out.println(method4(9));
		method5("오잉?", 3);
		System.out.println(method6(3));
		//maxNum
		System.out.println("큰 수는:" + maxNum(80, 90));
		//abs
		System.out.println("절대값은:" + abs(-200));
		//method7
		int[] arr = {1,2,3};
		System.out.println("길이:" + method7(arr));
		//method8
		String[] sArr = method8("안녕", "하세요");
		System.out.println(Arrays.toString(sArr));
	}
	
	static int method7(int[] arr) {
		
		return arr.length;
	}
	
	static String[] method8(String a, String b) {
		
		String[] arr = {a , b};
		
		return arr;
	}
	
	
	
	static void method1() {
		System.out.println("안녕");
	}
	static String method2(String str) {
		return str;
	}
	static double method3(int a, int b, double c) {
		return a+b+c;
	}
	static String method4(int a) {
		return a%2==0? "짝수": "홀수";
	}
	static void method5(String str, int a) {
		for(int i=1; i <= a; i++) {
			System.out.println(str);
		}
	}
	static int method6(int a) {
		int sum = 0;
		for (int i = 0; i <= a; i++) {
			sum+= i;
		}
		return sum;
	}
	static int maxNum(int a, int b) {
		if(a > b) {
			return a;
		} else {
			return b;
		}
	}
	
	static int abs(int a) {
		return a > 0 ? a : -a; //3항 연산식 사용
	}
	
}
