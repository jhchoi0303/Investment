package day08;

public class MethodEx02 {

	public static void main(String[] args) {
		/*
		 * 매개변수(parameter)
		 * 1. 매개변수는 메서드 호출에 필요한 값을 메서드에 전달하기 위한 매개체 입니다
		 * 2. 매개변수를 여러개 받아주고 싶다면  ,로 연결하면 됩니다
		 * 3. 매개변수를 하나도 받지 않을 수 있으며 이때는 ()를 비워둡니다
		 */
	
		System.out.println(calSum() );
		System.out.println(calSum() );
		
		String result = ran();
		System.out.println("랜덤값:" + result);
		
		
	}
	
	static String ran() {
		
		double d = Math.random();
		
		if(d > 0.66) {
			return "가위";
		} else if(d > 0.33) {
			return "바위";
		} else {
			return "보";
		}
		
	}
	
	
	
	static int calSum() {
		int sum = 0;
		for(int i = 1; i <= 100; i++) {
			sum += i;
		}
		return sum;
	}
	
	
	
	
}
