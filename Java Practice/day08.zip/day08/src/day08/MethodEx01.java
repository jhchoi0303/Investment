package day08;

public class MethodEx01 {

	public static void main(String[] args) {
		/*
		 * 1. 메서드 선언하는 과정, 호출하는 과정 이 있습니다
		 * 2. 메서드 선언은 메서드 내부에서 할 수 없습니다
		 * 3. 메서드 선언 위치는 클래스 어디서든지 가능합니다
		 * 
		 */
		
		System.out.println("1~10까지 합:" + calSum(10) );
		System.out.println("1~20까지 합:" + calSum(20) );

		int result = calSum(30);
		System.out.println("1~30까지 합:" + result);
		
		int result2 = calSum2(10, 20);
		System.out.println("10~20까지 합:" + result2);		
	
	}
	
	static int calSum2(int start, int end) {
		
		int sum = 0;
		for(int i = start; i <= end; i++) {
			sum += i;
		}
		return sum;
	}

	static int calSum(int end) {
		int sum = 0;
		for(int i = 1; i <= end; i++) {
			sum += i;
		}
		
		return sum;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
