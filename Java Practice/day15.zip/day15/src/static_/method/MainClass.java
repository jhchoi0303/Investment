package static_.method;

import java.util.Arrays;

public class MainClass {

	public static void main(String[] args) {
		
		Count c = new Count();
		c.a = 1;
		
		
		//b는 몇일까요? 4
		c.method1();
		c.b++;
		Count.method2();
		Count.b++;

		System.out.println(Count.b);
		
		//static 메서드 사용 예시
		Math.random(); //??
		Arrays.toString(new int[3]);
		Integer.parseInt("1");
		
		
		
		
		
		
		
		
	}
}
