package static_.method;

public class Count {

	public int a;
	public static int b;
	
	//일반 메서드 선언.
	//일반 메서드 안에서는 일반 멤버변수, 정적 멤버변수 모두 사용할 수 있습니다.
	public int method1() {
		a = 1;
		return ++b;
	}
	
	//정적 메서드 선언.
	public static int method2() {
		/*
		 * static메서드 안에서는 static이 붙은 변수나, 메서드만
		 * 참조가 가능합니다.
		 * 
		 * 단, 객체를 통해서는 일반 변수도 사용할 수 있습니다
		 * ex) main메서드
		 */
		//a = 1;
		Count c = new Count();
		c.a = 1;
		
		return ++b;
	}
	
	
}
