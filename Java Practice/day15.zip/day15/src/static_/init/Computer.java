package static_.init;

public class Computer {

	public static String company;
	public static String model;
	public static String info;
	
	public int price;
	
	//정적 변수를 초기화 할때는 정적 초기화자를 이용합니다.
	static {
		System.out.println("정적 초기화자 호출");
		company = "LG";
		model = "gram";
		info = company + "-" + model;
	}
	
	//일반 변수는 생성자에서 초기화.
	public Computer(){
		System.out.println("생성자 호출");
		this.price = 100000;
	}
	
	
	
	
}
