package static_.init;

public class MainClass {

	public static void main(String[] args) {
		
		/*
		 * 정적초기화자는 클래스가 호출 될때 단 한번 실행되는 특징을 갖고 있습니다.
		 * 
		 * 이 말은 static멤버들은 한번만 생성된다 라는 뜻입니다.
		 * 
		 */
		
		Computer com = new Computer();
		Computer com1 = new Computer();
//		System.out.println(Computer.company);
//		System.out.println(Computer.model);
//		System.out.println(Computer.info);
	}	
}
