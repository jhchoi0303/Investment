package static_.calc;

public class MainClass {

	public static void main(String[] args) {
		/*
		 * 1. 파랑색, 빨강색 계산기를 생성.
		 * 
		 * 2. 계산기 색깔을 출력하세요.
		 * 
		 * 3. pi를 이용해서 원의 넓이를 구하여 출력
		 *    circle()이용해서 원의 넓이를 출력 (static 사용방법을 이용해서)
		 */
		
		Calculator cal1 = new Calculator();
		Calculator cal2 = new Calculator();
		
		cal1.paint("빨강");
		cal2.paint("파랑");
		
		System.out.println("1번계산기 색:" + cal1.getColor());
		System.out.println("2번계산기 색:" + cal2.getColor());
		
		
		System.out.println(Calculator.pi * 4 * 4);
		System.out.println(Calculator.circle(4));
		
		
		
		
		
		
	}
}
