package static_.calc;

public class Calculator {
	

	//static이 언제 사용 되어야 하는가?
	/*
	 * 계산기 별로, 색상, 결과값은 다를 수 있기 때문에
	 * color, result같은 변수는 데이터를 공유시켜서는 안됩니다.
	 * 
	 * 객체별로 데이터를 따로 관리한다면, 일반 멤버변수로 선언.
	 */
	private String color;
	private int result;
	/*
	 * 계산기마다 원주율의 값은 동일하기 때문에
	 * 굳이 객체별로 저장할 필요없이 데이터를 공유시켜서 사용하는 편이 좋습니다.
	 */
	public static double pi = 3.14;
	
	
	/*
	 * 일반 멤버변수를 참조하는 메서드는 정적메서드로
	 * 선언하면 안됩니다.
	 * 
	 */
	public void paint(String color) {
		this.color = color;
	}
	
	public String getColor() {
		return color;
	}
	
	/*
	 * 메서드 내부에서 일반 멤버변수를 사용하지 않고,
	 * 범용성있게 사용되는 메서드는 static키워드를 사용해서
	 * 정적 메서드로 선언하는 편이 좋습니다.
	 */
	public static double circle(int r) {
		return r * r * pi;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
