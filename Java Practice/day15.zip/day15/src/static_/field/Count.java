package static_.field;

public class Count {

	//일반 멤버변수 선언
	public int a;
	//정적 멤버변수 선언
	public static int b;
}
