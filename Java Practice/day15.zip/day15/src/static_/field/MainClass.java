package static_.field;

public class MainClass {

	public static void main(String[] args) {
		
		Count c1 = new Count();
		c1.a++;
		c1.b++;
		System.out.println("일반 멤버변수 a:" + c1.a);
		System.out.println("정적 멤버변수 b:" + c1.b);
		
		Count c2 = new Count();
		c2.a++;
		c2.b++;
		System.out.println("일반 멤버변수 a:" + c2.a);
		System.out.println("정적 멤버변수 b:" + c2.b);
		
		Count c3 = new Count();
		c3.a++;
		c3.b++;
		System.out.println("일반 멤버변수 a:" + c3.a);
		System.out.println("정적 멤버변수 b:" + c3.b);
		
		
		/*
		 * 1. static멤버는 객체와 무관하기 때문에 
		 *    클래스 이름만으로 참조하여 사용합니다.
		 * ex) 클래스명.변수명
		 * 
		 * 2. static변수는 객체들 사이에서 같은 값을 갖는다. (값의 공유)
		 */
		
		
		Count.b++;
		Count.b++;
		Count.b = 10;
		
		System.out.println(c1.b);
		System.out.println(c2.b);
		System.out.println(Count.b);
		
		
		
		
		
		
		
		
	}
}
