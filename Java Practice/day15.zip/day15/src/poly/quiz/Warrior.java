package poly.quiz;

public class Warrior extends Player{

	Warrior(String name) {
		this.name = name;
		this.hp = 1000;
		this.mp = 500;
	}
		
	void bash(Player p) {
		
		if(this.mp < 100) {
			System.out.println("스킬을 사용할 수 없습니다");
			return; //메서드 강제 종료
		}
			
		System.out.println(p.name + "님이 스킬 적중");
		this.mp -= 100; //나의 마나 100씩 감소
		
		if(p instanceof Warrior) {
			p.hp -= 100; //전사 클래스 -100
		} else if(p instanceof Wizard) {
			p.hp -= 200; //마법사 클래스 -200
		}
	}
}
