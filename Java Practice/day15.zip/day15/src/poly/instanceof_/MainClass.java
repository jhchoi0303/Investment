package poly.instanceof_;

public class MainClass {

	public static void main(String[] args) {
		
		Person p = new Person("홍길동", 20);
		Person s = new Student("홍길자", 20, "123");
		Person t = new Teacher("김길동", 30, "컴퓨터");
		Person e = new Employee("고길동", 40, "설계");
			
		printInfo(p);
		printInfo(s);
		printInfo(t);
		printInfo(e);
	}
	
	
	public static void printInfo(Person p) {
		//instanceof 해당 객체에 대한 타입 확인 키워드
		if(p instanceof Student) {
			System.out.println("----학생 정보----");
		} else if(p instanceof Teacher) {
			System.out.println("----선생님 정보----");
		} else if(p instanceof Employee) {
			System.out.println("----직원 정보----");
		} else {
			System.out.println("----사람 정보----");
		}
		
		
		System.out.println(p.info());
		
	}
	
	
	
	
}
