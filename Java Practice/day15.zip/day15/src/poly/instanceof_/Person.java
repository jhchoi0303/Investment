package poly.instanceof_;

public class Person {
	
	String name;
	int age;
	
	Person(String name, int age) {
		super();//생략
		this.name = name;
		this.age = age;
		//System.out.println(this.info());
	}
	
	Person(String name) {
		this(name , 1);
		//this.name = name;
		//this.age = 1;
	}
	
	Person() {
		this("이름없음", 1);
		//this.name = "이름없음";
		//this.age = 1;
	}
	
	
	String info() {
		return "이름: " + name + ", 나이: " + age;
	}
}
