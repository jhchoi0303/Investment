package poly.instanceof_;

public class Mother extends Person {

	//아무것도 작성하지 않더라도 자동으로 생성자와, super() 동시에 생략
	Mother() {
		super();
	}
	
	
}
