package day03;

public class LogicalEx {

	public static void main(String[] args) {
		
		int x = 10, y = 20;
		
		//if뒤 () 안에 조건식 결과가 true 라면 if를 실행
		//false else블록을 실행.
		if( x != 10 & ++y == 21 ) {
			System.out.println("연산 결과가 참");
		} else {
			System.out.println("연산 결과가 거짓");
		}
		
		System.out.println("x:" + x + ", y:" + y);
		
		if( x == 10 | ++y == 21) {
			System.out.println("연산 결과가 참");
		} else {
			System.out.println("연산 결과가 거짓");
		}
		System.out.println("x:" + x + ", y:" + y);
		
		System.out.println("------------------------");
		
		int a = 10, b = 20;
		
		if( a != 10 && ++b == 21) { //뒤는 실행 하지 않음
			System.out.println("연산 결과가 참");
		} else {
			System.out.println("연산 결과가 거짓");
		}
		System.out.println("a:" + a + ", b:" + b);
		
		
		if( a == 10 || ++b == 21) { //뒤를 실행 하지 않음
			System.out.println("연산 결과가 참");
		} else {
			System.out.println("연산 결과가 거짓");
		}
		System.out.println("a:" + a + ", b:" + b);
		
		
		
		
		
		
	}
}
