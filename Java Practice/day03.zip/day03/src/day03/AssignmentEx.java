package day03;

public class AssignmentEx {

	public static void main(String[] args) {
	
		int a = 5, b = 5;
		
		a += 3; // a = a + 3;
		b =+ 3; // b = +3;
		
		System.out.println(a);
		System.out.println(b);
		
		a -= 4; //4
		
		a *= 6; //24 
		
		a /= 5; //4
		 
		a %= 3; //1
		
		System.out.println(a);
		
		
		
		
		
		
		
		
	}
}
