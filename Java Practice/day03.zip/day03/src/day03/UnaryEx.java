package day03;

public class UnaryEx {

	public static void main(String[] args) {
		
		//부호연산자
		int num1 = -5;
		int result = -num1;
		System.out.println(result);
		
		//증감연산자 ++, --
		int i = 1;
		int j = i++; //후위 연산자: 먼저 값을 저장하고, 자신을 증가
		
		System.out.println("i의 값:" + i);
		System.out.println("j의 값:" + j);
		
		int x = 1;
		int y = ++x; //전위 연산자: 먼저 자신을 증가, 값을 저장
		
		//x++;
		//i--;
		System.out.println("x의 값:" + x);
		System.out.println("y의 값:" + y);
				
		System.out.println("---------------------------");
		//논리 반전 연산자 (!)
		//true -> false, false-> true
		boolean bool = false;
		System.out.println(!bool);
		
		//비트 반전 연산자 ~
		//0 -> 1, 1 -> 0
		byte b = 8; //0000_1000
		System.out.println(~b); //1111_0111
		
		
		
		
		
		
		
		
		
		
		
	}
}
