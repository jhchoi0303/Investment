package day03;

public class CastingEx03 {

	public static void main(String[] args) {
		//int형보다 작은 타입의 연산은 최종 결과로 int형으로 반환
		char c = 'B';
		int i = 3;
		
		char cc = (char)(i + c);
		int ii = i + c;
		
		short s1 = 10;
		short s2 = 20;
		short s3 = (short)(s1 + s2);
		
		
		//int형보다 큰 타입의 연산에서는 최종 결과로 큰 타입으로 반환
		int j = 10;
		double d = j + 3.0;
		
		System.out.println(d);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
