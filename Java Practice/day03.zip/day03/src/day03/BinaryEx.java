package day03;

public class BinaryEx {

	public static void main(String[] args) {
		
		//산술연산
		int i = 7 / 3;
		int j = 7 % 3;
		System.out.println("i의 몫:" + i);
		System.out.println("j의 나머지:" + j);
		
		//비교 연산
		System.out.println(i == j);
		System.out.println(50 > 30);
		System.out.println(i != 1);
		System.out.println(100 < j);
		System.out.println(i % 15 == 0);
		
		boolean bool = i != j;
		
		//비트연산자 & | ^
		byte a = 5;//0000_0101
		byte b = 3;//0000_0011
		
		//비트곱: 두 비트중 둘다 1이면 1, 나머지는 0
		System.out.println(a & b);//0000_0001
		//비트합: 두 비트중 하나만 1이면 1, 나머지는 0
		System.out.println(a | b);//0000_0111
		//xor : 0은 제외, 두비트가 다르면 1, 같으면 0
		System.out.println(a ^ b);//0000_0110
		
		//비트 이동 연산 >>
		int k = 3; //0000_0011
		System.out.println(k << 2);//0000_1100
		
		
		
		
		
	}
	
}
