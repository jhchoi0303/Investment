package day03;

public class ConditionEx {

	public static void main(String[] args) {
		
		//Math.random() - 랜덤값을 발생시키는 기능
		//0.0 <= x < 1.0  미만 랜덤 실수값을 가져옴
		System.out.println( Math.random()  );
		
		double d = Math.random() * 10;
		int r = (int)d + 1; //실수부분은 버리고, 정수부분만 취함
		System.out.println(r);
		
		//한번에 쓰면?
		int ran = (int)(Math.random() * 10) + 1;
		System.out.println(ran);
		
		//3항 연산식을 적용
		String result = ran % 2 == 0 ? "참" : "거짓";
		System.out.println(result);
		
		
		
		
		
		
		
		
		
	}
}
