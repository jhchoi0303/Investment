package day03;

public class CastingEx01 {

	public static void main(String[] args) {
		/*
		 * 크기가 작은 데이터 타입을 큰 타입으로 변환할 때
		 * 자동으로 타입을 변환해줍니다.
		 * (promotion /Upcasting)
		 */
		
		byte b = 10;
		int i = b; //byte -> int형으로 자동 형변환
		System.out.println(i);
		
		char c = '가';
		int j = c; //char -> int형 자동 형변환
		System.out.println("가의 유니코드:" + j);
		
		int k = 700;
		double d = k; //int -> double
		System.out.println(d);
		
		
	}
}
