package day03;

public class CastingEx02 {

	public static void main(String[] args) {
		
		/*
		 * 크기가 큰 데이터 타입을 작은 데이터 타입으로 변환하려면 
		 * 캐스트 연산자(type) 사용해서 형변환을 해줘야 합니다.
		 */
		int i = 75;
		char c = (char)i;
		System.out.println("75에 해당하는 유니코드 문자값:" + c);
	
		
		double d = 4.234;
		int j = (int)d;
		System.out.println(j);
		
		/*
		 * 강제 타입변환을 할 때 주의할 점
		 * 해당 데이터 타입이 받을 수 없는 범위의
		 * 값이 들어오면 쓰레기값을 저장합니다.
		 * (overflow, underflow)
		 */
		
		int k = 500;
		byte b = (byte)k;
		System.out.println(b);
		
		
		
		
		
		
		
	}
}
