package day05;

import java.util.Scanner;

public class SwitchQuiz01 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);

		System.out.println("구입할 메뉴는?");
		System.out.println("[수박,사과,멜론,포도,귤]");
		System.out.print("> ");
		String fruit = scan.next();
	
		switch(fruit) {

		case "수박":
			System.out.println("수박 의 가격는 2만원입니다.");
			break;
		case "사과":
			System.out.println(fruit + "의 가격는 3만원입니다.");
			break;
		case "멜론":
			System.out.println(fruit + "의 가격는 4만원입니다.");
			break;
		case "포도":
			System.out.println(fruit + "의 가격는 5만원입니다.");
			break;
		case "귤":
			System.out.println(fruit + "의 가격는 6만원입니다.");
			break;
		default:
			System.out.println(fruit + "은 메뉴에 없습니다.");
			
		}
		
		
	}
}
