package day05;
import java.util.Scanner;

public class IfQuiz04 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("정수 입력>");
		int num = scan.nextInt();
		
		
		if(num >= 0) {
			
			if(num == 0) {
				System.out.println("0 입니다");
			} else if(num % 2 == 0) {
				System.out.println(num + "은 짝수 입니다");
			} else {
				System.out.println(num + "은 홀수 입니다");
			}
			
		} else {
			System.out.println(num + "은 음수 입니다");
		}
		
		
		System.out.println("---------------------------");
		
		if(num == 0) {
			System.out.println("0 입니다");
		} else if(num < 0) {
			System.out.println(num + "은 음수 입니다");
		} else if(num % 2 == 0) {
			System.out.println(num + "은 짝수 입니다");
		} else {
			System.out.println("홀수 입니다");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
