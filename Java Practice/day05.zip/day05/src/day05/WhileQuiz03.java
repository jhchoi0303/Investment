package day05;

public class WhileQuiz03 {

	public static void main(String[] args) {
		
		//0~1000까지 짝수의 합
		
		int i = 0;//제어 변수
		int sum = 0; //합계 변수
		
		while(i <= 1000) {
			
			if(i % 2 == 0) {
				sum = sum + i;
			}
			
			i++;
			
			//sum = sum + i;
			//i+=2;
		}
		
		System.out.println("1~1000까지 합:" + sum);
		
		
		
		
		
		
	}
}
