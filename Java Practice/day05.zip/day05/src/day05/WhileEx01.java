package day05;

public class WhileEx01 {

	public static void main(String[] args) {
		
		
		int a = 1; //제어 변수: 반복문의 반복횟수를 제어할 변수.
		
		while(a <= 100) {
			
			System.out.println(a);
			
			a++; //제어변수의 조작을 통해 언젠가는 조건이 false가 나오게 해야함 (증감식)
			//a+=2;
		}
		
		
		System.out.println("-------------------------------");
		
		int i = 1;//제어변수
		int sum = 0; //합계변수
		
		while(i <= 10) {
			
			sum = sum + i;
			
			i++;
		}
		
		System.out.println("1~10까지 합:" + sum);
		
		
		
		
		
		
		
	}
}
