package day05;

import java.util.Scanner;

public class WhileQuiz02 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.print("단수 입력>");
		int a = scan.nextInt();
		
		int i = 1; //제어변수
		System.out.println("구구단" + a + "단");
		while(i <= 9) {
			
			System.out.println(a + "x" + i + "=" + i*a);
			i++;
		}
		
	}
}





