package day05;

public class SwitchEx01 {

	public static void main(String[] args) {
		
		int a = 5;
		
		//switch() 소괄호 안에는 변수, 변수의 연산 ->값
		switch( a ) {
		
		case 0:
		case 1:
			System.out.println("1입니다");
			break;
		case 2:
			System.out.println("2입니다");
			break;
		case 3:
			System.out.println("3입니다");
			break;
		
		default :
			System.out.println("1~3이 아닙니다");
			
		}
		
		
		
		
		
		
		
		
		
		
		
	}
}
