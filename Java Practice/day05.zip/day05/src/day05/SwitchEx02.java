package day05;

import java.util.Scanner;

public class SwitchEx02 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("점수입력>");
		int point = scan.nextInt();
		
		/*
		 * switch 키워드 뒤에는 변수나, 변수의 연산식이 들어옴
		 * 그 결과값은 반드시 문자나, 정수형 이어야 합니다
		 * 
		 */
		switch (point / 10) {
		case 9:
			
			if(point >= 95) {
				System.out.println("A+학점 입니다");
			} else {
				System.out.println("A학점 입니다");
			}
			
			break;
		case 8:
			System.out.println("B학점 입니다");
			break;
		case 7:
			System.out.println("C학점 입니다");
			break;
		case 6:
			System.out.println("D학점 입니다");
			break;
		default:
			
			if(point == 100) {
				System.out.println("A+학점 입니다");
			} else if( point > 100) {
				System.out.println("잘못된 점수입니다");
			} else {
				System.out.println("F학점 입니다");
			}
			
			
			break;
		}
		
		
		
		
	}
}
