package day05;

public class SwitchQuiz02 {

	public static void main(String[] args) {
		
		//문자열 배열 안녕,헬로,니하오, ^&*를 저장
		//Math.random()을 이용해서 0~3까지 랜덤범위를 생성
		//배열의 랜덤값 을 출력
		
		//선택된 단어가 한국어 , 영어, 중국어, 외계어 인지 분기하는 스위치문
		
		String[] arr = {"안녕", "헬로", "니하오", "^&*"};
		int r = (int)(Math.random() * arr.length);
		
		System.out.println(arr[r]);
		
		switch( arr[r] ) {
		
		case "안녕":
			System.out.println("한국어");
			break;
		case "헬로":
			System.out.println("영어");
			break;
		case "니하오":
			System.out.println("중국어");
			break;
		default :
			System.out.println("외계어");
					
		}
		
		
		
		
		
		
		
		
		
		
		
	}
}
