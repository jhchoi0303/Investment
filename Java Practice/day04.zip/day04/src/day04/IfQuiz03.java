package day04;

public class IfQuiz03 {

	public static void main(String[] args) {
		
	}
}
