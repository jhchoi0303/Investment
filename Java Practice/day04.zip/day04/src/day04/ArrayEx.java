package day04;

import java.util.Arrays;

public class ArrayEx {

	public static void main(String[] args) {
		
		//1. 배열의 선언
		//int arr[]; //씨 언어 스타일
		int[] arr;
		
		//2. 배열의 생성
		arr = new int[5];
		System.out.println(arr); //배열의 0번쨰 상자가 만들어진 위치
		
		//3. 배열의 초기화 - 배열에 값을 저장하는 과정
		arr[0] = 43;
		arr[1] = 50;
		arr[2] = 23;
		arr[3] = 60;
		arr[4] = 70;
		
		//4. 배열의 사용
		System.out.println("배열의 4번째 데이터값:" + arr[3]);
		arr[3] = 100;
		System.out.println("배열의 4번째 데이터값:" + arr[3]);
		
		//5. 배열의 저장된 값들을 문자열형태 한눈에 볼 수 있는 기능
		//Arrays.toString(배열명)
		System.out.println( Arrays.toString(arr));
		
		//6. 배열의 길이를 확인할 수 있는 명령어  배열명.length
		System.out.println("배열의 길이:" + arr.length);
		
		//7. 배열의 선언과 생성을 동시에 하는 방법
		byte[] arr2 = new byte[7] ;
		
		//8. 배열의 선언과 생성과 초화를 동시에 하는 방법
		char[] arr3 = {'가', '나', '다' };
		
		//9. 배열의 초기값을 설정하지 않으면 배열의 값은 기본값으로 자동 초기화
		System.out.println(Arrays.toString(arr2) );
		
		
		
		System.out.println("----------------------------");
		//String배열 홍길동, 홍길자, 홍길숙 저장
		//3번째 값을 이순신 으로 변경
		//해당 배열의 생김새를 출력
		String[] arr4 = {"홍길동", "홍길자", "홍길숙"};
		arr4[2] = "이순신";
		System.out.println( Arrays.toString(arr4) );
		
		//double배열 1.1 2.2 3.3을 저장
		//각각 값을 출력
		
		double[] arr5 = new double[3];
		arr5[0] = 1.1;
		arr5[1] = 2.2;
		arr5[2] = 3.3;
		
		System.out.println(arr5[0]);
		System.out.println(arr5[1]);
		System.out.println(arr5[2]);
		
		
		
		
		
		
		
		
		
	}
}
