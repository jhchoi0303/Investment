package day04;

import java.util.Scanner;

public class IfQuiz01 {

	public static void main(String[] args) {
		
		//1. 스캐너를 통해 정수를 입력받음
		Scanner scan = new Scanner(System.in);
		
		System.out.print("정수입력>");
		int num = scan.nextInt();
		//2. if~else 구문을 사용해서 절대값으로 출력
				
		if(num >= 0) {
			System.out.println("절대값:" + num);
		} else {
			System.out.println("절대값:" + -num);
		}
		
		
		System.out.println("절대값:" + (num >= 0 ? num : -num) );
		
		
		scan.close();
		
		
	}
}
