package day04;

public class IfEx01 {

	public static void main(String[] args) {
		
		//0~100까지 랜덤수 발생
		int point = (int)(Math.random() * 101);
		System.out.println("점수:" + point);
		
		
		if(point >= 60) {
			System.out.println("합격입니다.");
		} else {
			System.out.println("불합격입니다.");
		}
		
		
		
		
//		if(point < 60) {
//			System.out.println("불합격입니다");
//		}
		
		
		
		
		
		
		
	}
}
