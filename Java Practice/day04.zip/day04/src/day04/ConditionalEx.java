package day04;

public class ConditionalEx {

	public static void main(String[] args) {
		
		int ran = (int)(Math.random() * 100) + 1;
		System.out.println("랜덤수:" + ran);
		System.out.println("3항연산식 결과:" + ( ran % 2 == 0 ? "짝수" : "홀수" )  );
		
		System.out.println("-------------------------");
		
		
		int ran2 = 5 - (int) (Math.random() * 10);
		
		System.out.println("랜덤수:" + ran2);
		
		int i = ran2 >= 0 ? ran2 : -ran2;
	
		System.out.println(ran2 + "의 절대값:" + i);
		
		
		
		
		
		
		
		
		
				
	}
}
