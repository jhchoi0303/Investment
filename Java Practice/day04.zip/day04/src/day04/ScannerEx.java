package day04;

import java.util.Scanner;

public class ScannerEx {

	public static void main(String[] args) {
		
		//1. 스캐너를 생성
		Scanner scan = new Scanner(System.in);
		
		//2. 스캐너가 가지고 있는 입력기능을 사용해서 데이터를 받음
		System.out.print("이름>");
		String name = scan.next(); //문자열
		
		System.out.print("나이>");
		int age = scan.nextInt(); //정수
		
		
		
		System.out.println("이름은?" + name + ", 나이는?" + age);
		
		
		//3. 스캐너 자원반납
		scan.close();
		
		
		
		
		
	}
}
