package generic.good;

public class Banana {

}
