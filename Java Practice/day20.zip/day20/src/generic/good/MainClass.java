package generic.good;

public class MainClass {

	public static void main(String[] args) {
		
		ABC<String> abc = new ABC<String>();
				
		abc.setT("홍길자");
		String name = abc.getT();
		
		
		ABC<Banana> abc2 = new ABC<>();
		
		abc2.setT(new Banana());
		Banana b = abc2.getT();
		
		
		/*
		 * 제네릭으로 클래스를 설계하게 되면 
		 * new로 객체를 생성할 때 타입을 지정해서 만들 수 있고,
		 * 반대로 객체를 가져올 때도 형변환 없이 해당타입을 곧바로 가져올 수 있습니다
		 * 
		 * 
		 */
		
	}
}
