package generic.good;

public class ABC<type> {

	private type t;
	
	public void setT(type t) {
		this.t = t;
	}
	
	public type getT() {
		return t;
	}
	
	
}
