package generic.bad;

public class MainClass {

	public static void main(String[] args) {
		
		ABC abc = new ABC();
		
		abc.setObj("홍길자");
		String name = (String)abc.getObj();
		
		
		abc.setObj( new Banana() );
		Banana b = (Banana)abc.getObj();
		
		//변수를 Object형 선언하면 무엇이든 저장할 수있지만,
		//반대로 저장했던 값을 사용할 때, 어떤 값이 저장되어 있는지도 알수 없고
		//타입별로 형변환 해야하는 문제가 발생..
		
		
		
	}
}
