package generic.bad;

public class Banana {

}
