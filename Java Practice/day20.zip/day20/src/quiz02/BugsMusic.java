package quiz02;

import java.util.ArrayList;

public class BugsMusic implements ISongList {

	
//	String[] list = new String[100];
//	int count = 0;
	
	ArrayList<String> list = new ArrayList<>();
	
	
	
	//ISongList를 상속받아 기능을 완성하세요
	//insertList(song) - list에 순서대로 저장
	//playList() - list를 랜덤으로 출력
	//length() - 저장된 음악 개수 리턴
	@Override
	public void insertList(String song) {
		//list[count] = song;
		//count++;
		list.add(song);
		
		
	}
	@Override
	public void playList() {
		
//		for(int i = 0; i < count; i++) {
//			int ran = (int)(Math.random() * count);
//			System.out.println(list[ran]);
//		}
		
		for(int i = 0; i < list.size(); i++) {
			int ran = (int)(Math.random() * list.size());
			System.out.println(list.get(ran));
		}
		
	}
	@Override
	public int length() {
		
		System.out.println(list.size() + "개의 음악을 저장중 입니다");
		
		return list.size();
	}
	

}
