package quiz02;

public class MelonMusic implements ISongList{
	
	String[] list = new String[100];
	int count = 0;
	//ISongList를 구현하여 기능을 완성하세요
	//insertList(song) - list에 순서대로 저장
	//playList() - list를 순서대로 출력
	//length() - 저장된 음악 개수 리턴
	
	public void insertList(String song) {
		list[count] = song;
		count++;
	}

	public void playList() {
		
		for(int i = 0; i < count; i++) {
			System.out.println(list[i]);
		}
	}

	public int length() {
		
		return count;
	}
}
