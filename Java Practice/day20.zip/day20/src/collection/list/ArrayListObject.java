package collection.list;

import java.util.ArrayList;
import java.util.List;

public class ArrayListObject {

	public static void main(String[] args) {
		
		
		List<User> list = new ArrayList<>();
		
		
		User u1 = new User("홍길동", 20);
		User u2 = new User("김길동", 30);
		User u3 = new User();
		u3.setName("홍길자");
		u3.setAge(40);
		
		
		list.add(u1);
		list.add(u2);
		list.add(u3);
		
		System.out.println(list.toString());
		
		
		System.out.println("--------------------------");
		//1. list에 저장된 모든 객체의 이름, 나이를 for문으로 출력
		for(int i = 0; i < list.size(); i++) {
			
			System.out.println( list.get(i).getName()  );
			System.out.println( list.get(i).getAge()   );
		}
		
		System.out.println("--------------------------");
		//2. list에 저장된 모든 객체의 이름, 나이를 향상된 for문 출력
		
		for(User u : list) {
			System.out.println(u.getName());
			System.out.println(u.getAge());
		}
		
		System.out.println("--------------------------");
		//3. list내에 user객체 안에 "김길동" 이 존재하면, 김길동의 이름과 나이만 출력
		
		for(int i = 0 ; i < list.size(); i++) {
			
			if(  list.get(i).getName().equals("김길동")   ) {
				
				System.out.println(list.get(i).getName() );
				System.out.println(list.get(i).getAge() );
			}
		}
		
		//4. list내에 "홍길자" 가 존재하면 홍길자 객체를 삭제
		
		for(int i = 0; i < list.size(); i++ ) {
			
			if( list.get(i).getName().equals("홍길자") ) {
				
				list.remove(i);
			}
			
		}
		
		System.out.println(list.toString());
		
		
		
		
		
	}
}
