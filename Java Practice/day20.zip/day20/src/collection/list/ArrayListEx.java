package collection.list;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx {

	public static void main(String[] args) {
		
		//ArrayList객체 생성
		//ArrayList<String> list = new ArrayList<>();
		List<String> list = new ArrayList<>();
	
		//list에 객체를 저장하는 메서드 add()
		list.add("java");
		list.add("jsp");
		list.add("JDBC");
		list.add("database");
		list.add("java");
		
		//list에 저장된 객체의 크기 size()
		System.out.println("list 크기:" + list.size());
		
		//list에 내부값 문자열로 출력 toString()
		System.out.println( list.toString());
		
		//list에 객체 저장 add(index, 객체)
		list.add(2, "spring");
		System.out.println(list.toString());
		
		//list에 객체 가져오기 get(index)
		String str = list.get(2);
		System.out.println("2번 인덱스에 들어있는 값:" + str);
		
		//list에 값 변경하기 set(index, 객체)
		list.set(3, "Oracle");
		System.out.println(list.toString());
		
		
		//list에 데이터 삭제 remove(index)
		list.remove(2);
		list.remove("Oracle");
		System.out.println(list.toString());
		
		//list에 전체 삭제 clear()
		list.clear();
		System.out.println(list.toString());
		
		
		
		
		if(list.isEmpty()) { 
			System.out.println("list가 비었음");
		}
		
		
		
		
		
		
	}
}
