package collection.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapEx {

	public static void main(String[] args) {
		
		//HashMap객체 생성
		Map<Integer, String> map = new HashMap<>();
		
		//map에 객체 저장 put(key, value)
		map.put(1, "햄버거");
		map.put(2, "치킨");
		map.put(3, "피자");
		map.put(4, "족발");
		
		System.out.println(map.toString());
		/*
		 * key에 중복 값을 저장했을 경우 
		 * 해당 key의 value를 수정합니다.
		 */
		map.put(4, "보쌈");
		System.out.println(map.toString());
		
		//map에 길이 size()
		System.out.println("map의 길이:" + map.size());
		
		//map에서 value값 얻기 get(key)
		String value = map.get(2);
		System.out.println("key가 2인 value:" + value);
		
		
		//map에 있는 값을 모두 출력하고 싶다면? KeySet()
		Set<Integer> set = map.keySet();
		
		System.out.println(set.toString());
		//저장된 모든 키를 Set에 담아서 리턴
		Iterator<Integer> iter = set.iterator();
		
		while(iter.hasNext()) {
			
			 Integer key = iter.next(); //key값을 반환
			 
			 System.out.println(  map.get(key) );
		}
		
		//객체 삭제 remove(key), clear()
		map.remove(2);
		System.out.println(map.toString());
		
		
		
		
		
		
		
		
	}
}
