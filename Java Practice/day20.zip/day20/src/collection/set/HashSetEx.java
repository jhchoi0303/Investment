package collection.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class HashSetEx {

	public static void main(String[] args) {
		
		//HashSet객체 생성
		Set<String> set = new HashSet<>();
		
		//set에 객체 add()
		set.add("java");
		set.add("jsp");
		set.add("jdbc");
		set.add("database");
		set.add("java"); //중복을 x
		
		//set에 저장된 길이 확인 size()
		System.out.println("set에 길이:" + set.size());
		
		System.out.println(set.toString());
		
		
		/*
		 * set의 저장된 값을 검색하려면 get()을 사용할 수 없고,
		 * 반복자 (iterator)를 통해 모든 객체를 대상으로 검색해야합니다.
		 */
		
		Iterator<String> iter = set.iterator();
		
		String str = iter.next();
		System.out.println(str);
		
		/*
		 * Iterator(반복자 객체) 가 next()메서드를 통해서 Set을 조회할 때 
		 * 더 이상 조회할 데이터가 없으면 예외를 발생시킵니다.
		 * 
		 * 그렇기 때문에 hasNext() 를 통해 Set내부 데이터를 조회할 수 있는지 유무를
		 * 검사 해야 합니다.
		 */
//		iter.next();
//		iter.next();
//		iter.next();
//		iter.next();
		
		while(iter.hasNext()) { //다음이 있으면 true, 없으면 false반환
			
			String s = iter.next();
			System.out.println(s);
		}
		
		//set데이터 삭제 기능 remove(), clear()
		set.remove("jdbc");
		System.out.println(set.toString());
		
		set.clear();
		System.out.println(set.toString());
		
		
		
		
		
		//Set 기능에 +자동정렬 
		//TreeSet객체 생성
		
		TreeSet<Integer> tree = new TreeSet<>();
		
		tree.add(100);
		tree.add(80);
		tree.add(40);
		tree.add(70);
		tree.add(1);
		
		System.out.println(tree.toString());
		
		
		
		
		
		
		
		
	}
}
